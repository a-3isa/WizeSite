// Buildozer v2 — shared primitives for the redesign prototype.
// All theming via CSS vars (theme.css) so light/dark + tweaks flow through.
(function () {
  const e = React.createElement;

  // ---- Icon (Material Symbols Outlined) ----
  function I({ n, s = 22, c = 'currentColor', fill = false, w = 400, style }) {
    return e('span', {
      className: 'material-symbols-outlined',
      style: {
        fontSize: s, width: s, height: s, color: c, lineHeight: 1,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        fontVariationSettings: `'FILL' ${fill ? 1 : 0}, 'wght' ${w}, 'GRAD' 0, 'opsz' 24`,
        flexShrink: 0, userSelect: 'none', ...style,
      },
    }, n);
  }

  // ---- Card ----
  function Card({ children, pad, style, onClick, elevated = false }) {
    return e('div', {
      onClick,
      style: {
        background: 'var(--surface)',
        border: '1px solid var(--border)',
        borderRadius: 'var(--r-lg)',
        boxShadow: elevated ? 'var(--shadow-md)' : 'var(--shadow-sm)',
        padding: pad != null ? pad : 'var(--card-pad)',
        cursor: onClick ? 'pointer' : 'default',
        ...style,
      },
    }, children);
  }

  // ---- Button ----
  function Btn({ children, variant = 'primary', size = 'md', icon, iconRight, full, disabled, onClick, style }) {
    const [h, setH] = React.useState(false);
    const heights = { sm: 40, md: 50, lg: 56 };
    const V = {
      primary: { bg: h ? 'var(--accent-press)' : 'var(--accent)', c: 'var(--on-accent)', bd: 'transparent' },
      soft: { bg: 'var(--accent-soft)', c: 'var(--accent)', bd: 'transparent' },
      outline: { bg: h ? 'var(--surface-2)' : 'var(--surface)', c: 'var(--text)', bd: 'var(--border-strong)' },
      ghost: { bg: h ? 'var(--surface-2)' : 'transparent', c: 'var(--text)', bd: 'transparent' },
      danger: { bg: h ? 'var(--expense)' : 'var(--expense-soft)', c: h ? '#fff' : 'var(--expense)', bd: 'transparent' },
    }[variant];
    return e('button', {
      onMouseEnter: () => setH(true), onMouseLeave: () => setH(false),
      onClick: disabled ? undefined : onClick, disabled,
      style: {
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
        height: heights[size], padding: size === 'sm' ? '0 14px' : '0 20px',
        width: full ? '100%' : 'auto', borderRadius: 'var(--r-md)',
        background: V.bg, color: V.c, border: `1.5px solid ${V.bd}`,
        fontFamily: 'var(--font)', fontWeight: 700, fontSize: size === 'sm' ? 14 : 15.5,
        cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.5 : 1,
        transition: 'background .15s, opacity .15s', whiteSpace: 'nowrap', ...style,
      },
    }, icon && e(I, { n: icon, s: size === 'sm' ? 18 : 20, c: 'currentColor' }), children,
       iconRight && e(I, { n: iconRight, s: size === 'sm' ? 18 : 20, c: 'currentColor' }));
  }

  // ---- Icon button ----
  function IconBtn({ n, s = 42, c = 'var(--text)', fill, onClick, badge, title, style }) {
    const [h, setH] = React.useState(false);
    return e('button', {
      title, 'aria-label': title, onClick,
      onMouseEnter: () => setH(true), onMouseLeave: () => setH(false),
      style: {
        position: 'relative', width: s, height: s, borderRadius: 'var(--r-pill)',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        border: 'none', background: h ? 'var(--surface-2)' : 'transparent',
        cursor: 'pointer', transition: 'background .15s', ...style,
      },
    }, e(I, { n, s: Math.round(s * 0.52), c, fill }),
       badge ? e('span', {
         style: {
           position: 'absolute', top: 6, right: 6, minWidth: 8, height: 8,
           borderRadius: 999, background: 'var(--expense)', border: '2px solid var(--surface)',
         },
       }) : null);
  }

  // ---- Segmented control ----
  function Segmented({ options, value, onChange, style }) {
    return e('div', {
      style: {
        display: 'inline-flex', background: 'var(--surface-2)', borderRadius: 'var(--r-pill)',
        padding: 3, gap: 2, ...style,
      },
    }, options.map((o) => {
      const on = o.value === value;
      return e('button', {
        key: o.value, onClick: () => onChange(o.value),
        style: {
          border: 'none', cursor: 'pointer', borderRadius: 'var(--r-pill)',
          padding: '6px 14px', fontFamily: 'var(--font)', fontSize: 13, fontWeight: 700,
          background: on ? 'var(--surface)' : 'transparent',
          color: on ? 'var(--text)' : 'var(--text-muted)',
          boxShadow: on ? 'var(--shadow-sm)' : 'none', transition: 'all .15s',
        },
      }, o.label);
    }));
  }

  // ---- Chip ----
  function Chip({ label, icon, dot, active, onClick, style }) {
    return e('button', {
      onClick,
      style: {
        display: 'inline-flex', alignItems: 'center', gap: 7, flex: '0 0 auto',
        padding: '9px 13px', borderRadius: 'var(--r-pill)',
        border: `1.5px solid ${active ? 'var(--accent)' : 'var(--border)'}`,
        background: active ? 'var(--accent-soft)' : 'var(--surface)',
        color: active ? 'var(--accent)' : 'var(--text)',
        fontFamily: 'var(--font)', fontSize: 13, fontWeight: 600,
        cursor: 'pointer', transition: 'all .15s', ...style,
      },
    }, dot && e('span', { style: { width: 8, height: 8, borderRadius: 999, background: dot } }),
       icon && e(I, { n: icon, s: 16, c: active ? 'var(--accent)' : 'var(--text-muted)' }), label);
  }

  // ---- Progress bar ----
  function Progress({ value, color = 'var(--accent)', track = 'var(--surface-3)', h = 8, style }) {
    return e('div', {
      style: { height: h, background: track, borderRadius: 999, overflow: 'hidden', ...style },
    }, e('div', { style: { width: `${Math.max(0, Math.min(1, value)) * 100}%`, height: '100%', background: color, borderRadius: 999, transition: 'width .4s' } }));
  }

  // ---- Section title ----
  function Section({ title, action, onAction, style }) {
    return e('div', {
      style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12, ...style },
    }, e('span', { style: { fontFamily: 'var(--font)', fontSize: 17, fontWeight: 750, color: 'var(--text)', letterSpacing: '-0.2px' } }, title),
       action && e('button', {
         onClick: onAction,
         style: { border: 'none', background: 'transparent', color: 'var(--accent)', fontFamily: 'var(--font)', fontSize: 13.5, fontWeight: 700, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 2 },
       }, action));
  }

  // ---- Avatar ----
  function Avatar({ label, size = 40, color = 'var(--accent)', style }) {
    const initials = (label || '?').split(' ').map((w) => w[0]).slice(0, 2).join('').toUpperCase();
    return e('div', {
      style: {
        width: size, height: size, borderRadius: 999, flexShrink: 0,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        background: 'var(--accent-soft)', color, fontFamily: 'var(--font)',
        fontWeight: 800, fontSize: size * 0.4, ...style,
      },
    }, initials);
  }

  // ---- Money row (transaction) ----
  function MoneyRow({ title, sub, amount, kind = 'expense', icon, currency = 'EGP', onClick, last }) {
    const income = kind === 'income';
    const col = income ? 'var(--income)' : 'var(--expense)';
    const softCol = income ? 'var(--income-soft)' : 'var(--expense-soft)';
    return e('div', {
      onClick,
      style: {
        display: 'flex', alignItems: 'center', gap: 12, padding: '12px 4px',
        borderBottom: last ? 'none' : '1px solid var(--border)', cursor: onClick ? 'pointer' : 'default',
      },
    },
      e('div', { style: { width: 40, height: 40, borderRadius: 12, flexShrink: 0, background: softCol, display: 'flex', alignItems: 'center', justifyContent: 'center' } },
        e(I, { n: icon || (income ? 'south_west' : 'north_east'), s: 20, c: col })),
      e('div', { style: { flex: 1, minWidth: 0 } },
        e('div', { style: { fontFamily: 'var(--font)', fontSize: 14.5, fontWeight: 650, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' } }, title),
        sub && e('div', { style: { fontFamily: 'var(--font)', fontSize: 12.5, color: 'var(--text-muted)', marginTop: 2 } }, sub)),
      e('div', { style: { textAlign: 'end', flexShrink: 0 } },
        e('div', { style: { fontFamily: 'var(--font)', fontSize: 14.5, fontWeight: 750, color: col } }, `${income ? '+' : '−'}${amount}`),
        e('div', { style: { fontFamily: 'var(--font)', fontSize: 11, color: 'var(--text-faint)', marginTop: 1 } }, currency)));
  }

  // ---- Form field (input) ----
  function Field({ label, value, onChange, placeholder, suffix, type = 'text', style }) {
    const [f, setF] = React.useState(false);
    return e('label', { style: { display: 'block', ...style } },
      label && e('span', { style: { display: 'block', marginBottom: 7, fontFamily: 'var(--font)', fontSize: 12.5, fontWeight: 650, color: 'var(--text-muted)' } }, label),
      e('div', {
        style: {
          display: 'flex', alignItems: 'center', gap: 8, background: 'var(--surface)',
          border: `${f ? 2 : 1.5}px solid ${f ? 'var(--accent)' : 'var(--border-strong)'}`,
          borderRadius: 'var(--r-md)', padding: f ? '13px 15px' : '14px 16px', transition: 'border-color .15s',
        },
      },
        e('input', {
          value, onChange, placeholder, type,
          onFocus: () => setF(true), onBlur: () => setF(false),
          style: { flex: 1, border: 'none', outline: 'none', background: 'transparent', fontFamily: 'var(--font)', fontSize: 16, fontWeight: 600, color: 'var(--text)', width: '100%' },
        }),
        suffix && e('span', { style: { fontFamily: 'var(--font)', fontSize: 13, fontWeight: 700, color: 'var(--text-muted)' } }, suffix)));
  }

  // ---- Select field (opens option list via onOpen) ----
  function SelectField({ label, valueLabel, icon, placeholder, onClick, style }) {
    return e('div', { style },
      label && e('span', { style: { display: 'block', marginBottom: 7, fontFamily: 'var(--font)', fontSize: 12.5, fontWeight: 650, color: 'var(--text-muted)' } }, label),
      e('button', {
        onClick,
        style: {
          display: 'flex', alignItems: 'center', gap: 10, width: '100%',
          background: 'var(--surface)', border: '1.5px solid var(--border-strong)',
          borderRadius: 'var(--r-md)', padding: '14px 16px', cursor: 'pointer', textAlign: 'start',
        },
      },
        icon && e(I, { n: icon, s: 20, c: 'var(--accent)' }),
        e('span', { style: { flex: 1, fontFamily: 'var(--font)', fontSize: 16, fontWeight: 650, color: valueLabel ? 'var(--text)' : 'var(--text-faint)' } }, valueLabel || placeholder),
        e(I, { n: 'expand_more', s: 22, c: 'var(--text-muted)' })));
  }

  window.BZ = { e, I, Card, Btn, IconBtn, Segmented, Chip, Progress, Section, Avatar, MoneyRow, Field, SelectField };
})();
