# Buildozer — Mobile App UI kit

A high-fidelity, interactive recreation of the Buildozer construction-tracking
app (Flutter + Firebase), built from the app's real theme and screen code.

## Flow
`index.html` is a click-through:
1. **Login** — logo, "Welcome back", Continue with Google.
2. **Dashboard** — workspace title, notifications badge + settings, the orange
   project selector, the 2×2 financial metric grid, a budget-used bar, the
   Recent transactions list, and the Resources link grid.
3. **Add Expense** — project + category selects, amount (EGP), supplier,
   payment method/status, notes, the voice-entry mic action, and Save.

Tap **Continue with Google** to enter, use the bottom nav (**Add** opens the
expense form), and **Save Expense** returns to the dashboard with a toast.

## Files
- `PhoneFrame.jsx` — device bezel + status bar
- `LoginScreen.jsx`
- `DashboardScreen.jsx`
- `AddExpenseScreen.jsx`
- `index.html` — app shell + navigation state

All screens compose the design-system primitives from `_ds_bundle.js`
(`window.BuildozerDesignSystem_b69712`) — no component logic is re-implemented
here. This is a cosmetic recreation, not production code.

## Source
Recreated from `a-3isa/WizeSite` (`lib/features/**`, `lib/app/theme`,
`lib/core/widgets`). Screens abbreviate repeated content (e.g. 3 recent rows).
