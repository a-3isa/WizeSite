// PhoneFrame — a lightweight device bezel for the Buildozer app screens.
function PhoneFrame({ children, statusColor = 'var(--color-text)' }) {
  return (
    <div style={{
      width: 340,
      background: 'var(--color-text)',
      borderRadius: 42,
      padding: 10,
      boxShadow: '0 24px 60px rgba(15,23,42,0.28)',
    }}>
      <div style={{
        position: 'relative',
        background: 'var(--color-bg)',
        borderRadius: 32,
        overflow: 'hidden',
        height: 720,
        display: 'flex',
        flexDirection: 'column',
      }}>
        {/* status bar */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '10px 22px 4px', fontSize: 12, fontWeight: 700,
          color: statusColor, fontFamily: 'var(--font-sans)', flexShrink: 0,
        }}>
          <span>9:41</span>
          <span style={{ display: 'inline-flex', gap: 5, alignItems: 'center' }}>
            <span className="material-symbols-outlined" style={{ fontSize: 15 }}>signal_cellular_alt</span>
            <span className="material-symbols-outlined" style={{ fontSize: 15 }}>wifi</span>
            <span className="material-symbols-outlined" style={{ fontSize: 16 }}>battery_full</span>
          </span>
        </div>
        {children}
      </div>
    </div>
  );
}
Object.assign(window, { PhoneFrame });
