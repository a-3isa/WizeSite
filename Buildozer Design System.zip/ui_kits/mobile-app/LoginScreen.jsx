// LoginScreen — Buildozer sign-in. Logo, welcome headline, Google button.
function LoginScreen({ onSignIn }) {
  const { Button } = window.BuildozerDesignSystem_b69712;
  return (
    <div style={{
      flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'stretch',
      justifyContent: 'center', padding: '0 28px', textAlign: 'center',
      fontFamily: 'var(--font-sans)',
    }}>
      <img src="../../assets/logo/app_icon.png" width="72" height="72"
        alt="Buildozer" style={{ borderRadius: 16, alignSelf: 'center', marginBottom: 24 }} />
      <div style={{ fontSize: 32, fontWeight: 900, letterSpacing: '-1px', color: 'var(--color-text)' }}>
        Welcome back
      </div>
      <div style={{ fontSize: 16, color: 'var(--color-text-body)', marginTop: 8, marginBottom: 44 }}>
        Sign in to continue
      </div>
      <button
        type="button"
        onClick={onSignIn}
        style={{
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
          height: 56, borderRadius: 'var(--radius-md)', cursor: 'pointer',
          background: 'var(--color-surface)', border: '1px solid var(--color-border)',
          fontFamily: 'var(--font-sans)', fontSize: 16, fontWeight: 700, color: 'var(--color-text)',
        }}>
        <img src="../../assets/logo/google_g.png" width="20" height="20" alt="" />
        Continue with Google
      </button>
      <div style={{ fontSize: 12, color: 'var(--color-text-body)', marginTop: 20, lineHeight: 1.5 }}>
        Field-ready construction tracking.<br />Log expenses by voice, on site.
      </div>
    </div>
  );
}
Object.assign(window, { LoginScreen });
