// AddExpenseScreen — Buildozer expense form. Project + category selects, amount
// with EGP suffix, payment method/status, notes, voice mic action, save.
function AddExpenseScreen({ onBack, onSave }) {
  const { IconButton, Select, TextField, Button, Icon } = window.BuildozerDesignSystem_b69712;
  const [project, setProject] = React.useState('villa');
  const [category, setCategory] = React.useState('materials');
  const [method, setMethod] = React.useState('cash');
  const [status, setStatus] = React.useState('unpaid');
  const [amount, setAmount] = React.useState('1,250,000');

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', fontFamily: 'var(--font-sans)', minHeight: 0 }}>
      {/* app bar */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '4px 8px 8px', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <IconButton icon="arrow_back" title="Back" onClick={onBack} />
          <span style={{ fontSize: 22, fontWeight: 700, color: 'var(--color-text)' }}>Add Expense</span>
        </div>
        <IconButton icon="mic" variant="filled" size={44} title="Voice entry" />
      </div>

      {/* scroll form */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '4px 16px 16px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        <Select label="Project" value={project} onChange={setProject} options={[
          { value: 'villa', label: 'Villa Project', icon: 'work' },
          { value: 'tower', label: 'Tower B Renovation', icon: 'work' },
          { value: 'warehouse', label: 'Warehouse Fit-out', icon: 'work' },
        ]} />
        <Select label="Category" value={category} onChange={setCategory} options={[
          { value: 'worker', label: 'Worker', icon: 'engineering', hint: 'daily wage' },
          { value: 'contractor', label: 'Contractor', icon: 'handyman' },
          { value: 'materials', label: 'Materials', icon: 'category' },
          { value: 'equipment', label: 'Equipment', icon: 'construction' },
          { value: 'transport', label: 'Transport', icon: 'local_shipping' },
          { value: 'other', label: 'Other', icon: 'more_horiz' },
        ]} />
        <TextField label="Amount" value={amount} suffix="EGP"
          onChange={(e) => setAmount(e.target.value)} />
        <TextField label="Supplier name" placeholder="Optional" onChange={() => {}} />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <Select label="Payment method" value={method} onChange={setMethod} options={[
            { value: 'cash', label: 'Cash' },
            { value: 'bank', label: 'Bank' },
            { value: 'check', label: 'Check' },
          ]} />
          <Select label="Payment status" value={status} onChange={setStatus} options={[
            { value: 'unpaid', label: 'Unpaid' },
            { value: 'partial', label: 'Partial' },
            { value: 'paid', label: 'Paid' },
          ]} />
        </div>
        <TextField label="Notes" multiline rows={2} placeholder="Add a note…" onChange={() => {}} />
        <Button variant="primary" icon="check" fullWidth size="lg" onClick={onSave} style={{ marginTop: 4 }}>
          Save Expense
        </Button>
      </div>
    </div>
  );
}
Object.assign(window, { AddExpenseScreen });
