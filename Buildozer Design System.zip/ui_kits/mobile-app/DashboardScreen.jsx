// DashboardScreen — Buildozer home. Workspace title + notifications/settings,
// project selector, financial metric grid, budget bar, recent list, resources.
function DashboardScreen({ onAdd, onOpenProject }) {
  const {
    IconButton, Badge, ProjectSelector, SectionHeader, MetricCard,
    Card, ProgressBar, TransactionRow, ResourceCard, Icon,
  } = window.BuildozerDesignSystem_b69712;

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', fontFamily: 'var(--font-sans)', minHeight: 0 }}>
      {/* app bar */}
      <div style={{ padding: '4px 12px 8px', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 4px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 22, fontWeight: 700, color: 'var(--color-text)' }}>
            Cairo Co.
            <Icon name="arrow_drop_down" size={22} color="var(--color-text)" />
          </div>
          <div style={{ display: 'flex', gap: 2 }}>
            <Badge count={3}><IconButton icon="notifications" title="Notifications" /></Badge>
            <IconButton icon="settings" title="Settings" />
          </div>
        </div>
        <div style={{ marginTop: 8 }}>
          <ProjectSelector project="Villa Project" onClick={onOpenProject} />
        </div>
      </div>

      {/* scroll */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '4px 16px 16px' }}>
        <SectionHeader title="Overview" style={{ margin: '6px 0 12px' }} />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <MetricCard label="Active projects" value="7" color="var(--color-orange)" icon="work" />
          <MetricCard label="Total expenses" value="195,500" color="var(--color-danger)" icon="trending_down" />
          <MetricCard label="Total income" value="320,000" color="var(--color-success)" icon="trending_up" />
          <MetricCard label="Net profit" value="124,500" color="var(--color-success)" icon="trending_up" />
        </div>

        <Card padding={14} style={{ marginTop: 16 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 8 }}>
            <span style={{ fontWeight: 700, color: 'var(--color-text)' }}>Budget used</span>
            <span style={{ color: 'var(--color-text-body)' }}>135,500 / 180,000</span>
          </div>
          <ProgressBar value={0.75} />
          <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--color-orange)', marginTop: 6 }}>75%</div>
        </Card>

        <SectionHeader title="Recent" style={{ margin: '20px 0 12px' }} />
        <Card padding={0}>
          <TransactionRow type="payment" title="Owner deposit" amount="120,000" />
          <TransactionRow type="expense" title="El-Nasr Supplies" amount="45,000" />
          <TransactionRow type="expense" title="Worker wages" amount="18,300" isLast />
        </Card>

        <SectionHeader title="Resources" style={{ margin: '20px 0 12px' }} />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
          <ResourceCard icon="engineering" label="Workers" color="var(--color-warning)" />
          <ResourceCard icon="handyman" label="Contractors" color="var(--color-orange)" />
          <ResourceCard icon="construction" label="Equipment" color="var(--color-success)" />
          <ResourceCard icon="local_shipping" label="Transport" color="var(--color-danger)" />
        </div>
      </div>
    </div>
  );
}
Object.assign(window, { DashboardScreen });
