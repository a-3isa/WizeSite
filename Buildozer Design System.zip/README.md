# Buildozer Design System

Brand and UI system for **Buildozer** — a mobile-first, field-ready
construction operations app. Contractors and site managers use it to track
project finances: expenses, payments, income, budgets, workers, contractors,
equipment and transport. Its signature feature is a **voice expense pipeline**
(record on site → transcribe → parse → confirm → save), and it is bilingual
(English + Arabic, LTR + RTL).

This project is the design guide, token library, component library and UI-kit
recreation used to generate on-brand Buildozer interfaces and assets.

## Sources

Everything here is derived from the product's own code:

- **GitHub:** `a-3isa/WizeSite` — https://github.com/a-3isa/WizeSite
  (Flutter + Firebase app; internal package name `buildtrack_app`).
  Key references: `lib/app/theme/app_theme.dart`,
  `lib/core/constants/app_colors.dart`, `lib/core/widgets/metric_card.dart`,
  `lib/features/**` (dashboard, expenses, auth), and `UX_Mockups.html`.

Explore the repository directly to build higher-fidelity work — the theme,
color constants, and feature screens are the ground truth for spacing, radii
and behavior.

---

## Content fundamentals

How Buildozer writes copy.

- **Tone:** plain, practical, jobsite-direct. Short imperative labels, no
  marketing fluff. It talks like a foreman, not a brand.
- **Voice / person:** addresses the user as **you** ("Sign in to continue",
  "Showing data for Villa Project only"). System states are stated flatly
  ("No data yet", "Queued for sync", "Some changes failed to sync").
- **Casing:** **Title Case for buttons and screen titles** ("Add Expense",
  "Save Expense", "Continue with Google", "Welcome back"). Sentence case for
  helper/body text. One deliberate **ALL-CAPS overline**: the orange `PROJECT`
  label on the dashboard project selector. Section headers are bold Title Case
  ("Overview", "Resources", "Recent", "Weekly summary").
- **Numbers & money:** amounts always use **live thousands separators**
  (`320,000`, `1,250,000`) — comma-grouped, app-wide, in every numeric field.
  Currency shown as a **trailing code** (`124,500 EGP`), default **EGP**.
  Money direction is explicit: **funds in** = payment/income, **funds out** =
  expense.
- **Domain vocabulary:** Project, Workspace, Expense, Payment, Category,
  Worker, Contractor, Equipment, Transport, Materials, Budget, Net profit,
  Supplier, Payment method (Cash / Bank / Check), Payment status (Unpaid /
  Partial / Paid).
- **Errors:** specific and human ("No account found for that email",
  "Incorrect password", "Please select a project and enter a valid amount"),
  never raw codes.
- **Emoji:** **not used** in the shipped app UI (emoji appear only in an
  internal mockup file). Use Material icons instead — never emoji.
- **Vibe:** trustworthy, fast, low-friction. The number you opened the app for
  should be the first thing you see.

---

## Visual foundations

- **Color:** a single hot brand accent — **Construction Orange `#FF6D00`** —
  against a cool, calm neutral field (Slate). Orange is reserved for primary
  action, the active nav/selection state, and the project scope control. It is
  used solid for CTAs, at a **10–12% tint** for selected/indicator surfaces,
  and as **`#FFF0E6`** for soft badges. Backgrounds are **`#F8FAFC`** (app) and
  **white** (cards). Text is Slate-900 `#0F172A` (headings) over Slate-500
  `#64748B` (body). See `tokens/colors.css`.
- **Semantic money colors:** green `#10B981` = income / funds in;
  red `#EF4444` = expense / funds out; amber `#F59E0B` = workers / pending.
  Each has a light tint for chips/badges.
- **Type:** **Inter** for the Latin UI, **Cairo** for Arabic (loaded via the
  Flutter `google_fonts` package; we load the same families from Google Fonts).
  Heavy weights carry the brand — values are **800 (extrabold)**, the login
  headline is **900 (black)**, titles **700**. Display/heading text uses tight
  **negative letter-spacing** (−0.5 to −1px). Body is 16px at 1.5 line-height.
- **Backgrounds:** flat and quiet — solid `#F8FAFC`. **No gradients** in the
  product UI (the only gradient is a faint hero wash in an unshipped mockup —
  avoid it). No photography, patterns or textures in-app. The one raster image
  is the orange bulldozer app icon.
- **Cards:** white surface, **1px `#E2E8F0` hairline border**, **16–20px**
  radius, and a **soft shadow** (`0 3–4px 10px rgba(15,23,42,0.05)`). The
  metric card adds a **3px colored top bar** keyed to meaning and a circular
  tinted icon badge.
- **Corner radii:** 8 (small controls) · 12 (inputs, buttons, chips) · 16
  (cards, lists) · 20 (large cards) · 28 (FAB) · pill (badges, nav indicator,
  status tags).
- **Elevation / shadows:** one gentle house shadow; the bottom nav casts an
  upward shadow (`0 -2px 12px rgba(15,23,42,0.10)`). No hard/dark shadows, no
  neumorphism. Inner shadows are not used.
- **Borders:** hairline `#E2E8F0` everywhere; inputs get a **2px orange**
  border on focus, **red** on error.
- **Buttons:** filled orange (white text) for primary; bordered white for
  secondary; soft-orange tonal; text-only ghost. Radius 12, bold label,
  tall touch target (primary CTAs are **56px**, full-width).
- **Hover / press:** web hover darkens the primary orange slightly and adds an
  orange **10% tint** wash on plain icon buttons / links; cards lift with the
  soft shadow. Native press is a Material ink ripple — approximate with a quick
  background tint, not a scale/bounce.
- **Motion:** minimal and functional — short `.12–.3s` ease transitions
  (background, border, progress-bar width). No bounces, no decorative looping
  animation.
- **Transparency & blur:** used sparingly — color-at-alpha tints for
  selection/badges only. No glassmorphism / backdrop blur.
- **Layout:** mobile-first single column. Page padding 16–20px, a 12px rhythm
  between cards, and a 2-column grid for metrics and resources. Fixed elements:
  top app bar (workspace + actions, with the project selector docked beneath
  it) and the bottom navigation bar.
- **Imagery vibe:** the brand's only image is the warm-orange, flat,
  white-on-orange bulldozer icon — friendly, industrial, high-contrast. No
  photographic or duotone treatments.

---

## Iconography

- **Set:** **Material Symbols / Material Icons, Outlined** style — the Flutter
  app uses Material `Icons.*_outlined`. We load **Material Symbols Outlined**
  from Google Fonts (see `tokens/fonts.css`) and expose it via the `Icon`
  component. Use outlined weights; the active bottom-nav icon fills.
- **How to use:** `<Icon name="work" />` or the raw
  `<span class="material-symbols-outlined">work</span>`. Common glyphs:
  `work` (project), `mic` (voice expense), `trending_up` / `trending_down`
  (income / expense), `south_west` / `north_east` (funds in / out),
  `engineering` (workers), `handyman` (contractors), `construction`
  (equipment), `local_shipping` (transport), `category` (materials),
  `notifications`, `settings`, `home`, `add_circle`, `arrow_drop_down`,
  `cloud_upload` / `sync_problem` (offline sync).
- **Color:** icons take the semantic color of their context (orange for brand,
  green/red for money, category colors for resources). Default is Slate body.
- **Emoji / unicode:** **not used** as icons in the product. Do not substitute
  emoji for Material glyphs.
- **Logo assets:** in `assets/logo/` — `app_icon.png` (orange bulldozer mark),
  `app_icon_foreground.png` (white bulldozer, for placing on orange),
  `splash.png`, and `google_g.png` (used on the sign-in button). These were
  copied from the app's `assets/branding/`.

---

## Index / manifest

**Foundations**
- `styles.css` — root entry (import this one file)
- `tokens/colors.css` · `tokens/typography.css` · `tokens/spacing.css` · `tokens/fonts.css`
- `guidelines/*.card.html` — specimen cards (Colors, Type, Spacing, Brand)

**Assets**
- `assets/logo/` — app icon, foreground mark, splash, Google G

**Components** (`window.BuildozerDesignSystem_b69712`)
- base: `Icon`, `Chip`
- forms: `Button`, `IconButton`, `TextField`, `Select`
- data-display: `Card`, `MetricCard`, `SectionHeader`, `ProgressBar`, `TransactionRow`, `StatusTag`
- navigation: `BottomNav`, `ProjectSelector`, `ResourceCard`
- feedback: `Badge`, `EmptyState`, `Toast`

Each component directory has a `.jsx` + `.d.ts` + `.prompt.md` and a
`@dsCard` demo HTML.

**UI kits**
- `ui_kits/mobile-app/` — interactive Login → Dashboard → Add Expense recreation

**Other**
- `SKILL.md` — Agent Skill wrapper
- `README.md` — this guide

---

## Caveats

- Fonts are loaded from **Google Fonts** (Inter, Cairo, Material Symbols),
  matching the app's `google_fonts` usage — no local font binaries are shipped.
- Slide templates are not included (no deck source exists in the repo).
