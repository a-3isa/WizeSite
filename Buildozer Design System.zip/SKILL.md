---
name: buildozer-design
description: Use this skill to generate well-branded interfaces and assets for Buildozer, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick reference
- **Brand accent:** Construction Orange `#FF6D00` (primary action, active state). Tints `#FFF0E6` / 10–12% alpha for selection.
- **Neutrals:** app bg `#F8FAFC`, cards white, border `#E2E8F0`, heading `#0F172A`, body `#64748B`.
- **Money colors:** income/funds-in green `#10B981`, expense/funds-out red `#EF4444`, workers amber `#F59E0B`.
- **Type:** Inter (Latin) + Cairo (Arabic). Heavy weights (800/900), tight negative letter-spacing on headings.
- **Icons:** Material Symbols Outlined only — never emoji.
- **Cards:** white, 1px hairline border, 16–20px radius, soft shadow; metric cards add a 3px colored top bar.
- **Buttons:** filled orange primary (56px, radius 12, bold); bordered secondary; tonal; ghost.
- **Copy:** Title Case buttons/titles, sentence-case body, "you", plain jobsite tone, comma-grouped amounts + trailing currency (EGP).

## Files
- `README.md` — full design guide (content, visual, iconography, manifest)
- `styles.css` + `tokens/` — CSS custom properties and fonts
- `components/` — React primitives (`.jsx` + `.d.ts` + `.prompt.md`)
- `guidelines/` — foundation specimen cards
- `ui_kits/mobile-app/` — interactive app recreation
- `assets/logo/` — logo + branding images
