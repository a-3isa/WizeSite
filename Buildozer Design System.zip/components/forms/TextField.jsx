import React from 'react';

/**
 * TextField — the app's outlined input. White fill, 12px radius, hairline
 * border that turns orange (2px) on focus, red on error. Supports a floating
 * label, hint, error text and optional suffix (e.g. currency "EGP").
 */
export function TextField({
  label,
  value,
  placeholder,
  suffix,
  hint,
  error,
  multiline = false,
  rows = 3,
  disabled = false,
  onChange,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const borderColor = error
    ? 'var(--color-danger)'
    : focus
    ? 'var(--color-orange)'
    : 'var(--color-border)';

  const fieldStyle = {
    display: 'flex',
    alignItems: 'center',
    gap: 8,
    background: disabled ? 'var(--color-bg)' : 'var(--color-surface)',
    border: `${focus && !error ? 2 : 1}px solid ${borderColor}`,
    borderRadius: 'var(--radius-md)',
    padding: focus && !error ? '15px 15px' : '16px',
    transition: 'border-color .15s ease',
  };
  const inputBase = {
    flex: 1,
    border: 'none',
    outline: 'none',
    background: 'transparent',
    font: 'inherit',
    fontFamily: 'var(--font-sans)',
    fontSize: 'var(--fs-body-sm)',
    fontWeight: 'var(--fw-semibold)',
    color: 'var(--color-text)',
    resize: multiline ? 'vertical' : 'none',
    width: '100%',
  };

  return (
    <label style={{ display: 'block', ...style }}>
      {label && (
        <span
          style={{
            display: 'block',
            marginBottom: 6,
            fontFamily: 'var(--font-sans)',
            fontSize: 'var(--fs-label)',
            fontWeight: 'var(--fw-semibold)',
            color: 'var(--color-text-body)',
          }}
        >
          {label}
        </span>
      )}
      <div style={fieldStyle}>
        {multiline ? (
          <textarea
            rows={rows}
            value={value}
            placeholder={placeholder}
            disabled={disabled}
            onChange={onChange}
            onFocus={() => setFocus(true)}
            onBlur={() => setFocus(false)}
            style={inputBase}
            {...rest}
          />
        ) : (
          <input
            value={value}
            placeholder={placeholder}
            disabled={disabled}
            onChange={onChange}
            onFocus={() => setFocus(true)}
            onBlur={() => setFocus(false)}
            style={inputBase}
            {...rest}
          />
        )}
        {suffix && (
          <span
            style={{
              fontFamily: 'var(--font-sans)',
              fontSize: 'var(--fs-label)',
              fontWeight: 'var(--fw-semibold)',
              color: 'var(--color-text-body)',
            }}
          >
            {suffix}
          </span>
        )}
      </div>
      {(error || hint) && (
        <span
          style={{
            display: 'block',
            marginTop: 6,
            fontFamily: 'var(--font-sans)',
            fontSize: 'var(--fs-label)',
            color: error ? 'var(--color-danger)' : 'var(--color-text-body)',
          }}
        >
          {error || hint}
        </span>
      )}
    </label>
  );
}
