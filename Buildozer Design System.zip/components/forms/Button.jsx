import React from 'react';
import { Icon } from '../base/Icon.jsx';

/**
 * Button — Buildozer's primary action control. Mirrors the Flutter FilledButton
 * (orange fill, white text) and OutlinedButton (bordered) themes: 12px radius,
 * bold label, tall touch target.
 */
export function Button({
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  disabled = false,
  icon,
  iconRight,
  children,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const heights = { sm: 44, md: 52, lg: 56 };

  const variants = {
    primary: {
      background: 'var(--color-orange)',
      color: '#fff',
      border: '1px solid transparent',
      hoverBg: '#E85F00',
    },
    secondary: {
      background: 'var(--color-surface)',
      color: 'var(--color-text)',
      border: '1px solid var(--color-border)',
      hoverBg: '#F1F5F9',
    },
    tonal: {
      background: 'var(--color-orange-light)',
      color: 'var(--color-orange)',
      border: '1px solid transparent',
      hoverBg: '#FFE3CE',
    },
    ghost: {
      background: 'transparent',
      color: 'var(--color-orange)',
      border: '1px solid transparent',
      hoverBg: 'var(--color-orange-light)',
    },
  };
  const v = variants[variant] || variants.primary;

  return (
    <button
      type="button"
      onClick={disabled ? undefined : onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      disabled={disabled}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        height: heights[size],
        padding: size === 'sm' ? '0 16px' : '0 24px',
        width: fullWidth ? '100%' : 'auto',
        borderRadius: 'var(--radius-md)',
        fontFamily: 'var(--font-sans)',
        fontWeight: 'var(--fw-bold)',
        fontSize: size === 'sm' ? 14 : 16,
        letterSpacing: 0,
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.45 : 1,
        transition: 'background .15s ease, box-shadow .15s ease',
        background: hover && !disabled ? v.hoverBg : v.background,
        color: v.color,
        border: v.border,
        ...style,
      }}
      {...rest}
    >
      {icon && <Icon name={icon} size={size === 'sm' ? 18 : 20} color="currentColor" />}
      {children}
      {iconRight && <Icon name={iconRight} size={size === 'sm' ? 18 : 20} color="currentColor" />}
    </button>
  );
}
