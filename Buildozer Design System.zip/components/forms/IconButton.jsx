import React from 'react';
import { Icon } from '../base/Icon.jsx';

/**
 * IconButton — square icon-only control used in app bars (notifications,
 * settings, voice mic). Subtle tinted hover, circular hit area.
 */
export function IconButton({
  icon,
  size = 40,
  iconSize,
  color = 'var(--color-text-body)',
  variant = 'plain',
  disabled = false,
  onClick,
  title,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const filled = variant === 'filled';
  return (
    <button
      type="button"
      title={title}
      aria-label={title}
      onClick={disabled ? undefined : onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      disabled={disabled}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        width: size,
        height: size,
        borderRadius: 'var(--radius-pill)',
        border: 'none',
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.45 : 1,
        background: filled
          ? 'var(--color-orange)'
          : hover
          ? 'var(--color-orange-10)'
          : 'transparent',
        transition: 'background .15s ease',
        ...style,
      }}
      {...rest}
    >
      <Icon
        name={icon}
        size={iconSize || Math.round(size * 0.55)}
        color={filled ? '#fff' : color}
      />
    </button>
  );
}
