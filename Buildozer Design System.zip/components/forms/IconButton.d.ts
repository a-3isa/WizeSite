import React from 'react';

export interface IconButtonProps {
  /** Material Symbols icon name. */
  icon: string;
  /** Button box size in px. Default 40. */
  size?: number;
  /** Icon glyph size; defaults to ~55% of size. */
  iconSize?: number;
  /** Icon color (plain variant). Default body slate. */
  color?: string;
  /** plain = transparent w/ tinted hover; filled = orange circle (FAB-like). */
  variant?: 'plain' | 'filled';
  disabled?: boolean;
  onClick?: () => void;
  /** Accessible label / tooltip. */
  title?: string;
  style?: React.CSSProperties;
}

/**
 * Buildozer icon-only button (app-bar actions, FAB).
 */
export function IconButton(props: IconButtonProps): JSX.Element;
