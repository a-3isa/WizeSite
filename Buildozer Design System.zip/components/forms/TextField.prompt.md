**TextField** — the outlined input used throughout expense/payment forms. Hairline border goes orange (2px) on focus, red on error. Add a `suffix` for currency, `multiline` for notes.

```jsx
<TextField label="Amount" value="1,250,000" suffix="EGP" />
<TextField label="Supplier name" placeholder="Optional" />
<TextField label="Notes" multiline rows={3} />
<TextField label="Email" error="No account found for that email" />
```

Amounts use live thousands separators app-wide (comma-grouped).
