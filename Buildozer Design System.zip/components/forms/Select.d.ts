import React from 'react';

export interface SelectOption {
  value: string;
  label: string;
  /** Optional leading Material Symbols icon. */
  icon?: string;
  /** Optional trailing hint text (e.g. "daily wage"). */
  hint?: string;
}

export interface SelectProps {
  label?: string;
  /** Currently selected value. */
  value?: string;
  placeholder?: string;
  options: SelectOption[];
  disabled?: boolean;
  onChange?: (value: string) => void;
  style?: React.CSSProperties;
}

/**
 * Buildozer dropdown / "below dropdown" select (category, project, payment method).
 */
export function Select(props: SelectProps): JSX.Element;
