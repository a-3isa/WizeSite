**Select** — the app's dropdown field. It opens an inline menu beneath the field (the "below dropdown" pattern); the selected option is orange-tinted. Options can carry a leading icon and a trailing hint.

```jsx
<Select
  label="Category"
  value="materials"
  onChange={setCat}
  options={[
    { value: 'worker', label: 'Worker', icon: 'engineering', hint: 'daily wage' },
    { value: 'materials', label: 'Materials', icon: 'category' },
    { value: 'equipment', label: 'Equipment', icon: 'construction' },
  ]}
/>
```

Used for Project, Category, Payment method (cash/bank/check), Payment status (unpaid/partial/paid).
