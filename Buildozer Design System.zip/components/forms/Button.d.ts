import React from 'react';

export interface ButtonProps {
  /** Visual style. primary = orange fill; secondary = bordered white; tonal = orange tint; ghost = text-only. */
  variant?: 'primary' | 'secondary' | 'tonal' | 'ghost';
  /** Height preset. sm 44px · md 52px · lg 56px. Default md. */
  size?: 'sm' | 'md' | 'lg';
  /** Stretch to container width. */
  fullWidth?: boolean;
  disabled?: boolean;
  /** Leading Material Symbols icon name. */
  icon?: string;
  /** Trailing Material Symbols icon name (e.g. "arrow_forward"). */
  iconRight?: string;
  children?: React.ReactNode;
  onClick?: () => void;
  style?: React.CSSProperties;
}

/**
 * Buildozer action button (FilledButton / OutlinedButton parity).
 *
 * @startingPoint section="Forms" subtitle="Primary, secondary, tonal & ghost buttons" viewport="700x180"
 */
export function Button(props: ButtonProps): JSX.Element;
