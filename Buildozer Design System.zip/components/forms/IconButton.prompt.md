**IconButton** — square, icon-only control for app bars and floating actions. `plain` sits on transparent with an orange-tint hover; `filled` is the solid orange circle (FAB / voice record).

```jsx
<IconButton icon="notifications" title="Notifications" />
<IconButton icon="settings" title="Settings" />
<IconButton icon="mic" variant="filled" size={56} title="Record" />
```
