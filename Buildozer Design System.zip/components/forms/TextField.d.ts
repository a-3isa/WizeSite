import React from 'react';

export interface TextFieldProps {
  /** Field label shown above the input. */
  label?: string;
  value?: string;
  placeholder?: string;
  /** Trailing text, e.g. a currency code "EGP". */
  suffix?: string;
  /** Helper text under the field. */
  hint?: string;
  /** Error text; turns the border and message red. */
  error?: string;
  /** Render a multi-line textarea. */
  multiline?: boolean;
  rows?: number;
  disabled?: boolean;
  onChange?: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  style?: React.CSSProperties;
}

/**
 * Buildozer outlined text input (amount, notes, supplier, etc).
 */
export function TextField(props: TextFieldProps): JSX.Element;
