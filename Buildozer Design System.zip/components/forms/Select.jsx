import React from 'react';
import { Icon } from '../base/Icon.jsx';

/**
 * Select — the "below dropdown" field pattern from the app: a bordered field
 * that opens an inline menu of options beneath it. White surface, 12px radius,
 * focus/open border turns orange. Selected option is orange-tinted.
 */
export function Select({
  label,
  value,
  placeholder = 'Select…',
  options = [],
  disabled = false,
  onChange,
  style,
  ...rest
}) {
  const [open, setOpen] = React.useState(false);
  const selected = options.find((o) => o.value === value);
  const borderColor = open ? 'var(--color-orange)' : 'var(--color-border)';

  return (
    <div style={{ ...style }} {...rest}>
      {label && (
        <span
          style={{
            display: 'block',
            marginBottom: 6,
            fontFamily: 'var(--font-sans)',
            fontSize: 'var(--fs-label)',
            fontWeight: 'var(--fw-semibold)',
            color: 'var(--color-text-body)',
          }}
        >
          {label}
        </span>
      )}
      <button
        type="button"
        disabled={disabled}
        onClick={() => setOpen((o) => !o)}
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          width: '100%',
          background: 'var(--color-surface)',
          border: `${open ? 2 : 1}px solid ${borderColor}`,
          borderRadius: 'var(--radius-md)',
          padding: open ? '15px' : '16px',
          cursor: disabled ? 'not-allowed' : 'pointer',
          fontFamily: 'var(--font-sans)',
          fontSize: 'var(--fs-body-sm)',
          fontWeight: 'var(--fw-semibold)',
          color: selected ? 'var(--color-text)' : 'var(--color-text-body)',
          textAlign: 'left',
        }}
      >
        {selected?.icon && (
          <Icon name={selected.icon} size={18} color="var(--color-orange)" />
        )}
        <span style={{ flex: 1 }}>{selected ? selected.label : placeholder}</span>
        <Icon
          name={open ? 'arrow_drop_up' : 'arrow_drop_down'}
          size={22}
          color="var(--color-text-body)"
        />
      </button>
      {open && (
        <div
          style={{
            marginTop: 6,
            background: 'var(--color-surface)',
            border: '1px solid var(--color-border)',
            borderRadius: 'var(--radius-md)',
            boxShadow: 'var(--shadow-soft)',
            overflow: 'hidden',
          }}
        >
          {options.map((opt, i) => {
            const isActive = opt.value === value;
            return (
              <button
                key={opt.value}
                type="button"
                onClick={() => {
                  onChange && onChange(opt.value);
                  setOpen(false);
                }}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 9,
                  width: '100%',
                  padding: '11px 12px',
                  border: 'none',
                  borderBottom:
                    i < options.length - 1 ? '1px solid var(--color-bg)' : 'none',
                  background: isActive ? 'var(--color-orange-light)' : 'transparent',
                  color: isActive ? 'var(--color-orange)' : 'var(--color-text)',
                  fontFamily: 'var(--font-sans)',
                  fontSize: 'var(--fs-body-sm)',
                  fontWeight: isActive ? 'var(--fw-bold)' : 'var(--fw-medium)',
                  cursor: 'pointer',
                  textAlign: 'left',
                }}
              >
                {opt.icon && (
                  <Icon
                    name={opt.icon}
                    size={18}
                    color={isActive ? 'var(--color-orange)' : 'var(--color-text-body)'}
                  />
                )}
                <span style={{ flex: 1 }}>{opt.label}</span>
                {opt.hint && (
                  <span
                    style={{
                      fontSize: 'var(--fs-label)',
                      color: 'var(--color-text-body)',
                      fontWeight: 'var(--fw-medium)',
                    }}
                  >
                    {opt.hint}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
