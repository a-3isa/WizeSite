**Button** — the app's main action control. `primary` is the orange filled CTA (Save Expense, Continue); `secondary` is the bordered white button (Continue with Google); `tonal` is the soft-orange fill; `ghost` is text-only.

```jsx
<Button variant="primary" icon="check" fullWidth>Save Expense</Button>
<Button variant="secondary" icon="add">Add Project</Button>
<Button variant="tonal">Select Attachments</Button>
<Button variant="ghost" iconRight="arrow_forward">See all</Button>
```

Sizes: `sm` 44 · `md` 52 · `lg` 56 (brand CTAs are 56 full-width). Radius is always 12px; label is bold.
