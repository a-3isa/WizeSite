import React from 'react';
import { Icon } from '../base/Icon.jsx';

/**
 * MetricCard — the dashboard KPI card. White surface with a 3px colored top
 * bar, a label + circular tinted icon badge, and a large extrabold value.
 * Faithful to lib/core/widgets/metric_card.dart.
 */
export function MetricCard({
  label,
  value,
  color = 'var(--color-text)',
  icon = 'bar_chart',
  style,
  ...rest
}) {
  return (
    <div
      style={{
        background: 'var(--color-surface)',
        border: '1px solid var(--color-border)',
        borderRadius: 'var(--radius-lg)',
        boxShadow: 'var(--shadow-card)',
        overflow: 'hidden',
        ...style,
      }}
      {...rest}
    >
      <div style={{ height: 3, background: color }} />
      <div style={{ padding: '12px 14px 14px' }}>
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: 8,
          }}
        >
          <span
            style={{
              fontFamily: 'var(--font-sans)',
              fontSize: 'var(--fs-label)',
              fontWeight: 'var(--fw-medium)',
              color: 'var(--color-text-body)',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap',
            }}
          >
            {label}
          </span>
          <span
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              width: 26,
              height: 26,
              borderRadius: '50%',
              background: `color-mix(in srgb, ${color} 12%, transparent)`,
              flexShrink: 0,
            }}
          >
            <Icon name={icon} size={14} color={color} />
          </span>
        </div>
        <div
          style={{
            marginTop: 10,
            fontFamily: 'var(--font-sans)',
            fontSize: 'var(--fs-value)',
            fontWeight: 'var(--fw-extrabold)',
            letterSpacing: 'var(--ls-value)',
            color: 'var(--color-text)',
          }}
        >
          {value}
        </div>
      </div>
    </div>
  );
}
