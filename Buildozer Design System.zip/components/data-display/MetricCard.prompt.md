**MetricCard** — the dashboard KPI card: a 3px colored top bar, a label with a circular tinted icon badge, and a big extrabold number. Color the card by meaning.

```jsx
<MetricCard label="Total income" value="320,000" color="var(--color-success)" icon="trending_up" />
<MetricCard label="Total expenses" value="195,500" color="var(--color-danger)" icon="trending_down" />
<MetricCard label="Active projects" value="7" color="var(--color-orange)" icon="work" />
```

Typically laid out in a 2×2 grid (childAspectRatio ~1.35).
