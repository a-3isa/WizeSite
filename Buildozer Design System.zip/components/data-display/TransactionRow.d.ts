import React from 'react';

export interface TransactionRowProps {
  /** Description, e.g. "El-Nasr Supplies". */
  title: string;
  /** Formatted amount without sign, e.g. "45,000". */
  amount: string;
  /** payment = funds in (green +) · expense = funds out (red -). */
  type?: 'payment' | 'expense';
  /** Removes the bottom divider on the last row. */
  isLast?: boolean;
  onClick?: () => void;
  style?: React.CSSProperties;
}

/**
 * Buildozer recent-transactions list row.
 */
export function TransactionRow(props: TransactionRowProps): JSX.Element;
