**StatusTag** — a small uppercase pill for statuses and markers. Map payment status to tone: Paid → success, Partial → warning, Unpaid → danger.

```jsx
<StatusTag label="Paid" tone="success" />
<StatusTag label="Partial" tone="warning" />
<StatusTag label="Unpaid" tone="danger" />
<StatusTag label="New" tone="orange" />
```
