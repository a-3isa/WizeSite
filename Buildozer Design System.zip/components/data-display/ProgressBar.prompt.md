**ProgressBar** — the project budget-used bar. Orange fill on a light-orange track; switch `color` to danger when over budget.

```jsx
<ProgressBar value={0.75} />
<ProgressBar value={1} color="var(--color-danger)" />
```
