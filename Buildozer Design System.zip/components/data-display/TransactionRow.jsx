import React from 'react';
import { Icon } from '../base/Icon.jsx';

/**
 * TransactionRow — a row in the dashboard "Recent" list. Payments (funds in)
 * show a green south-west arrow and a green +amount; expenses (funds out) a red
 * north-east arrow and a red -amount.
 */
export function TransactionRow({
  title,
  amount,
  type = 'expense',
  isLast = false,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const isPayment = type === 'payment';
  const color = isPayment ? 'var(--color-success)' : 'var(--color-danger)';
  const sign = isPayment ? '+' : '-';
  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        padding: '11px 12px',
        borderBottom: isLast ? 'none' : '1px solid var(--color-bg)',
        background: hover && onClick ? 'var(--color-bg)' : 'transparent',
        cursor: onClick ? 'pointer' : 'default',
        transition: 'background .12s ease',
        ...style,
      }}
      {...rest}
    >
      <Icon name={isPayment ? 'south_west' : 'north_east'} size={18} color={color} />
      <span
        style={{
          flex: 1,
          fontFamily: 'var(--font-sans)',
          fontSize: 'var(--fs-body-sm)',
          color: 'var(--color-text)',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          whiteSpace: 'nowrap',
        }}
      >
        {title}
      </span>
      <span
        style={{
          fontFamily: 'var(--font-sans)',
          fontSize: 'var(--fs-body-sm)',
          fontWeight: 'var(--fw-bold)',
          color,
        }}
      >
        {sign}
        {amount}
      </span>
    </div>
  );
}
