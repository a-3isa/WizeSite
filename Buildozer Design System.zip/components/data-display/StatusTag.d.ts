import React from 'react';

export interface StatusTagProps {
  label: string;
  /** Color tone. paid→success, partial→warning, unpaid→danger, etc. */
  tone?: 'success' | 'warning' | 'danger' | 'orange' | 'neutral';
  style?: React.CSSProperties;
}

/**
 * Buildozer status pill (payment status, NEW / NOW markers).
 */
export function StatusTag(props: StatusTagProps): JSX.Element;
