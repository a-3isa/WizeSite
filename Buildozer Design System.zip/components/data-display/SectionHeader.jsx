import React from 'react';

/**
 * SectionHeader — the uppercase-ish bold section label used above dashboard
 * groups ("Overview", "Resources", "Recent"). Optional trailing action.
 */
export function SectionHeader({ title, action, style, ...rest }) {
  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        ...style,
      }}
      {...rest}
    >
      <span
        style={{
          fontFamily: 'var(--font-sans)',
          fontSize: 'var(--fs-title)',
          fontWeight: 'var(--fw-bold)',
          color: 'var(--color-text)',
        }}
      >
        {title}
      </span>
      {action}
    </div>
  );
}
