import React from 'react';

export interface MetricCardProps {
  /** Small label, e.g. "Total income". */
  label: string;
  /** Formatted value, e.g. "320,000" or "7". */
  value: string;
  /** Accent color for the top bar + icon badge. Use a semantic token. */
  color?: string;
  /** Material Symbols icon name. Default "bar_chart". */
  icon?: string;
  style?: React.CSSProperties;
}

/**
 * Buildozer dashboard KPI card (colored top bar + value).
 *
 * @startingPoint section="Data display" subtitle="Dashboard KPI metric card" viewport="360x150"
 */
export function MetricCard(props: MetricCardProps): JSX.Element;
