import React from 'react';

/**
 * ProgressBar — the budget-used bar. Rounded track (orange 10% tint) with an
 * orange fill; turns red when over budget. Matches the project budget bar.
 */
export function ProgressBar({
  value = 0,
  color = 'var(--color-orange)',
  height = 8,
  track = 'var(--color-orange-10)',
  style,
  ...rest
}) {
  const pct = Math.max(0, Math.min(1, value)) * 100;
  return (
    <div
      style={{
        height,
        background: track,
        borderRadius: 'var(--radius-sm)',
        overflow: 'hidden',
        ...style,
      }}
      {...rest}
    >
      <div
        style={{
          width: `${pct}%`,
          height: '100%',
          background: color,
          borderRadius: 'var(--radius-sm)',
          transition: 'width .3s ease',
        }}
      />
    </div>
  );
}
