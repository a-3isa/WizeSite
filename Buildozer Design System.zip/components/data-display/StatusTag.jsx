import React from 'react';

const TONES = {
  success: { bg: 'var(--color-success-light)', fg: 'var(--color-success)' },
  warning: { bg: 'var(--color-warning-light)', fg: 'var(--color-warning)' },
  danger: { bg: 'var(--color-danger-light)', fg: 'var(--color-danger)' },
  orange: { bg: 'var(--color-orange-light)', fg: 'var(--color-orange)' },
  neutral: { bg: 'var(--color-bg)', fg: 'var(--color-text-body)' },
};

/**
 * StatusTag — a small rounded pill for statuses (payment status, NEW/NOW tags).
 * Tinted background + matching text color.
 */
export function StatusTag({ label, tone = 'neutral', style, ...rest }) {
  const t = TONES[tone] || TONES.neutral;
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        padding: '3px 10px',
        borderRadius: 'var(--radius-pill)',
        background: t.bg,
        color: t.fg,
        fontFamily: 'var(--font-sans)',
        fontSize: 'var(--fs-overline)',
        fontWeight: 'var(--fw-bold)',
        letterSpacing: '0.03em',
        textTransform: 'uppercase',
        ...style,
      }}
      {...rest}
    >
      {label}
    </span>
  );
}
