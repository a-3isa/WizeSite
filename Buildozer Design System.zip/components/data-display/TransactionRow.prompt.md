**TransactionRow** — one line of the Recent list. `payment` = money in (green, `+`, south-west arrow); `expense` = money out (red, `-`, north-east arrow). Stack rows inside a `Card` with `padding={0}`.

```jsx
<Card padding={0}>
  <TransactionRow type="payment" title="Owner deposit" amount="120,000" />
  <TransactionRow type="expense" title="El-Nasr Supplies" amount="45,000" />
  <TransactionRow type="expense" title="Worker wages" amount="18,300" isLast />
</Card>
```
