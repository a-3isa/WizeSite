import React from 'react';

export interface SectionHeaderProps {
  title: string;
  /** Optional trailing element (e.g. a "See all" ghost button). */
  action?: React.ReactNode;
  style?: React.CSSProperties;
}

/**
 * Buildozer section header label.
 */
export function SectionHeader(props: SectionHeaderProps): JSX.Element;
