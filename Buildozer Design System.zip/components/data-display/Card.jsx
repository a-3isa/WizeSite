import React from 'react';

/**
 * Card — the base white surface used across the app: rounded, hairline border,
 * soft shadow. Everything (metrics, lists, budget bars) sits on this.
 */
export function Card({ padding = 14, radius = 'var(--radius-lg)', children, style, ...rest }) {
  return (
    <div
      style={{
        background: 'var(--color-surface)',
        border: '1px solid var(--color-border)',
        borderRadius: radius,
        boxShadow: 'var(--shadow-card)',
        padding,
        ...style,
      }}
      {...rest}
    >
      {children}
    </div>
  );
}
