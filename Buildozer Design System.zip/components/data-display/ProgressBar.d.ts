import React from 'react';

export interface ProgressBarProps {
  /** Fill fraction 0–1. */
  value: number;
  /** Fill color. Default orange; pass danger when over budget. */
  color?: string;
  /** Bar height in px. Default 8. */
  height?: number;
  /** Track color. Default orange 10% tint. */
  track?: string;
  style?: React.CSSProperties;
}

/**
 * Buildozer budget-used progress bar.
 */
export function ProgressBar(props: ProgressBarProps): JSX.Element;
