**SectionHeader** — bold title above a dashboard group (Overview, Resources, Recent). Optional trailing `action`.

```jsx
<SectionHeader title="Overview" />
<SectionHeader title="Recent" action={<Button variant="ghost" size="sm">See all</Button>} />
```
