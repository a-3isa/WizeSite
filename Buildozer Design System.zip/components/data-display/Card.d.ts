import React from 'react';

export interface CardProps {
  /** Inner padding in px. Default 14. */
  padding?: number | string;
  /** Corner radius CSS value. Default var(--radius-lg) (16px). */
  radius?: string;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

/**
 * Buildozer base surface card (white, hairline border, soft shadow).
 */
export function Card(props: CardProps): JSX.Element;
