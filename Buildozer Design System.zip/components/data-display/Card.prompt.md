**Card** — the base white surface (rounded 16px, hairline border, soft shadow). Wrap any grouped content in it.

```jsx
<Card padding={16}>
  <h3>Budget used</h3>
  ...
</Card>
```
