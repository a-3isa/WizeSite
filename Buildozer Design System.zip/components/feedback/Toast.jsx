import React from 'react';
import { Icon } from '../base/Icon.jsx';

/**
 * Toast — the snackbar / inline notice. A dark or tinted pill with an optional
 * leading icon and a trailing text action. Used for "Queued for sync", errors.
 */
export function Toast({ message, icon, tone = 'dark', actionLabel, onAction, style, ...rest }) {
  const tones = {
    dark: { bg: 'var(--color-text)', fg: '#fff', accent: '#fff' },
    success: { bg: 'var(--color-success-light)', fg: 'var(--color-success)', accent: 'var(--color-success)' },
    warning: { bg: 'var(--color-warning-light)', fg: '#7A4A00', accent: 'var(--color-warning)' },
    danger: { bg: 'var(--color-danger-light)', fg: 'var(--color-danger)', accent: 'var(--color-danger)' },
  };
  const t = tones[tone] || tones.dark;
  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        padding: '12px 14px',
        borderRadius: 'var(--radius-md)',
        background: t.bg,
        color: t.fg,
        boxShadow: 'var(--shadow-soft)',
        fontFamily: 'var(--font-sans)',
        fontSize: 'var(--fs-body-sm)',
        ...style,
      }}
      {...rest}
    >
      {icon && <Icon name={icon} size={20} color={t.accent} />}
      <span style={{ flex: 1 }}>{message}</span>
      {actionLabel && (
        <button
          type="button"
          onClick={onAction}
          style={{
            border: 'none',
            background: 'transparent',
            color: t.accent,
            fontFamily: 'var(--font-sans)',
            fontSize: 'var(--fs-body-sm)',
            fontWeight: 'var(--fw-bold)',
            cursor: 'pointer',
            padding: 0,
          }}
        >
          {actionLabel}
        </button>
      )}
    </div>
  );
}
