**Badge** — a red count indicator, usually overlaid on the notifications icon button. Overlays `children`, or renders inline when standalone.

```jsx
<Badge count={3}><IconButton icon="notifications" /></Badge>
<Badge dot><IconButton icon="notifications" /></Badge>
```
