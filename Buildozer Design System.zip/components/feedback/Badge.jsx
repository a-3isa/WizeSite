import React from 'react';

/**
 * Badge — a small count indicator (e.g. unread notifications) that overlays a
 * child, or renders standalone. Danger-red dot with white number, like the
 * notifications Badge in the app bar.
 */
export function Badge({ count, dot = false, max = 99, children, color = 'var(--color-danger)', style, ...rest }) {
  const show = dot || (typeof count === 'number' && count > 0);
  const text = count > max ? `${max}+` : `${count}`;
  const badge = show && (
    <span
      style={{
        position: children ? 'absolute' : 'static',
        top: children ? -4 : undefined,
        right: children ? -4 : undefined,
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        minWidth: dot ? 10 : 18,
        height: dot ? 10 : 18,
        padding: dot ? 0 : '0 5px',
        borderRadius: 'var(--radius-pill)',
        background: color,
        color: '#fff',
        fontFamily: 'var(--font-sans)',
        fontSize: 11,
        fontWeight: 'var(--fw-bold)',
        lineHeight: 1,
        border: children ? '2px solid var(--color-surface)' : 'none',
        boxSizing: 'border-box',
      }}
    >
      {!dot && text}
    </span>
  );

  if (!children) return badge || null;
  return (
    <span style={{ position: 'relative', display: 'inline-flex', ...style }} {...rest}>
      {children}
      {badge}
    </span>
  );
}
