import React from 'react';
import { Icon } from '../base/Icon.jsx';

/**
 * EmptyState — the centered placeholder shown when a list has no data (recent
 * transactions, restricted reports). A muted circular icon, a message, and an
 * optional action.
 */
export function EmptyState({ icon = 'inbox', message, action, style, ...rest }) {
  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        textAlign: 'center',
        gap: 12,
        padding: '32px 24px',
        ...style,
      }}
      {...rest}
    >
      <span
        style={{
          display: 'inline-flex',
          alignItems: 'center',
          justifyContent: 'center',
          width: 56,
          height: 56,
          borderRadius: '50%',
          background: 'var(--color-bg)',
        }}
      >
        <Icon name={icon} size={26} color="var(--color-text-body)" />
      </span>
      <span
        style={{
          fontFamily: 'var(--font-sans)',
          fontSize: 'var(--fs-body-sm)',
          color: 'var(--color-text-body)',
          maxWidth: 260,
        }}
      >
        {message}
      </span>
      {action}
    </div>
  );
}
