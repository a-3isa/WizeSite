**EmptyState** — centered placeholder for empty lists (no recent activity, restricted access).

```jsx
<EmptyState icon="receipt_long" message="No data yet" />
<EmptyState icon="lock" message="You don't have access to financial reports" />
```
