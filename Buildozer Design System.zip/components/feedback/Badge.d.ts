import React from 'react';

export interface BadgeProps {
  /** Numeric count. Hidden when 0/undefined unless `dot`. */
  count?: number;
  /** Render a bare dot instead of a number. */
  dot?: boolean;
  /** Cap displayed number (e.g. 99 → "99+"). Default 99. */
  max?: number;
  /** Badge color. Default danger red. */
  color?: string;
  /** Element to overlay; omit to render the badge inline. */
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

/**
 * Buildozer notification / count badge.
 */
export function Badge(props: BadgeProps): JSX.Element;
