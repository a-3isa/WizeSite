**Toast** — the snackbar / inline banner for transient feedback and sync/queue status. Dark by default; use tinted tones for status banners.

```jsx
<Toast message="Queued for sync" icon="cloud_upload" />
<Toast tone="warning" icon="cloud_upload" message="3 changes waiting to sync" actionLabel="Sync status" />
<Toast tone="danger" icon="sync_problem" message="Some changes failed to sync" actionLabel="Review" />
```
