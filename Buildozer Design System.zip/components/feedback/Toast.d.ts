import React from 'react';

export interface ToastProps {
  message: string;
  /** Optional leading Material Symbols icon. */
  icon?: string;
  /** Color tone. Default dark snackbar. */
  tone?: 'dark' | 'success' | 'warning' | 'danger';
  /** Trailing text-button label. */
  actionLabel?: string;
  onAction?: () => void;
  style?: React.CSSProperties;
}

/**
 * Buildozer snackbar / inline notice.
 */
export function Toast(props: ToastProps): JSX.Element;
