import React from 'react';

export interface EmptyStateProps {
  /** Material Symbols icon name. Default "inbox". */
  icon?: string;
  message: string;
  /** Optional action element (e.g. a Button). */
  action?: React.ReactNode;
  style?: React.CSSProperties;
}

/**
 * Buildozer empty / no-data placeholder.
 */
export function EmptyState(props: EmptyStateProps): JSX.Element;
