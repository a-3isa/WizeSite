import React from 'react';

export interface IconProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Material Symbols Outlined glyph name, e.g. "work", "mic", "trending_up". */
  name: string;
  /** Glyph size in px. Default 20. */
  size?: number;
  /** CSS color. Default currentColor. */
  color?: string;
  /** Optical weight 100–700. Default 400. */
  weight?: number;
  /** Filled vs outlined variant. Default false (outlined). */
  fill?: boolean;
}

/**
 * Buildozer icon glyph (Material Symbols Outlined).
 */
export function Icon(props: IconProps): JSX.Element;
