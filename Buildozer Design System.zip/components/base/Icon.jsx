import React from 'react';

/**
 * Icon — renders a Material Symbols Outlined glyph, the icon set the Buildozer
 * Flutter app uses (Material outlined icons). Pass the Material Symbols name.
 */
export function Icon({
  name,
  size = 20,
  color = 'currentColor',
  weight = 400,
  fill = false,
  style,
  ...rest
}) {
  return (
    <span
      className="material-symbols-outlined"
      aria-hidden="true"
      style={{
        fontSize: size,
        width: size,
        height: size,
        color,
        lineHeight: 1,
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontVariationSettings: `'FILL' ${fill ? 1 : 0}, 'wght' ${weight}, 'GRAD' 0, 'opsz' 24`,
        userSelect: 'none',
        flexShrink: 0,
        ...style,
      }}
      {...rest}
    >
      {name}
    </span>
  );
}
