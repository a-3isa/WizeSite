**Icon** — a single Material Symbols Outlined glyph, matching the Flutter app's outlined Material icons. Use anywhere the brand needs an icon (buttons, list rows, nav, metrics).

```jsx
<Icon name="work" size={18} color="var(--color-orange)" />
<Icon name="trending_up" color="var(--color-success)" />
<Icon name="mic" fill />
```

Common glyphs in Buildozer: `work` (project), `mic` (voice), `trending_up`/`trending_down` (income/expense), `engineering` (workers), `handyman` (contractors), `construction` (equipment), `local_shipping` (transport), `notifications`, `settings`, `add`, `home`.
