import React from 'react';

export interface ChipProps {
  /** Chip label text. */
  label: string;
  /** Optional square color dot on the left (e.g. category color). */
  dotColor?: string;
  /** Optional Material Symbols icon name instead of / with a dot. */
  icon?: string;
  /** Icon color. Default brand orange. */
  iconColor?: string;
  /** Selected state — orange tinted background + border. */
  active?: boolean;
  /** Click handler; makes the chip interactive with a hover shadow. */
  onClick?: () => void;
  style?: React.CSSProperties;
}

/**
 * Buildozer quick-access / category chip.
 */
export function Chip(props: ChipProps): JSX.Element;
