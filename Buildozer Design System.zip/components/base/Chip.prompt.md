**Chip** — the small bordered pill from the dashboard "Quick access" strip. Shows a color dot or icon plus a bold label; can be toggled `active` (orange tint).

```jsx
<Chip label="Workers" dotColor="var(--color-warning)" onClick={() => {}} />
<Chip label="Materials" icon="category" active />
```

Category dot colors follow the resource palette: Workers → warning, Contractors → orange, Equipment → success, Transport → danger.
