import React from 'react';
import { Icon } from './Icon.jsx';

/**
 * Chip — the small pill used in the dashboard "Quick access" strip and for
 * resource categories. A leading color dot (or icon) plus a bold label on a
 * white bordered surface.
 */
export function Chip({
  label,
  dotColor,
  icon,
  iconColor,
  active = false,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const clickable = !!onClick;
  return (
    <button
      type="button"
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      disabled={!clickable}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 8,
        flex: '0 0 auto',
        padding: '9px 12px',
        borderRadius: 'var(--radius-md)',
        border: `1px solid ${active ? 'var(--color-orange)' : 'var(--color-border)'}`,
        background: active ? 'var(--color-orange-light)' : 'var(--color-surface)',
        color: active ? 'var(--color-orange)' : 'var(--color-text)',
        font: 'inherit',
        fontFamily: 'var(--font-sans)',
        fontSize: 'var(--fs-label)',
        fontWeight: 'var(--fw-bold)',
        cursor: clickable ? 'pointer' : 'default',
        boxShadow: hover && clickable ? 'var(--shadow-card)' : 'none',
        transition: 'box-shadow .15s, border-color .15s',
        ...style,
      }}
      {...rest}
    >
      {dotColor && (
        <span
          style={{
            width: 9,
            height: 9,
            borderRadius: 3,
            background: dotColor,
            flexShrink: 0,
          }}
        />
      )}
      {icon && <Icon name={icon} size={16} color={iconColor || 'var(--color-orange)'} />}
      {label}
    </button>
  );
}
