**ProjectSelector** — the orange control under the dashboard app bar that scopes all data to one project (or "All Projects"). Small orange PROJECT overline + extrabold name + caret.

```jsx
<ProjectSelector project="Villa Project" onClick={openMenu} />
<ProjectSelector project="All Projects" open />
```
