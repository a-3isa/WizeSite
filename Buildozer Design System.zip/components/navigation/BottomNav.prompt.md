**BottomNav** — the app's tab bar. Active tab gets an orange pill behind a filled icon and a bold orange label.

```jsx
<BottomNav
  value="home"
  onChange={setTab}
  items={[
    { value: 'home', label: 'Home', icon: 'home' },
    { value: 'add', label: 'Add', icon: 'add_circle' },
    { value: 'projects', label: 'Projects', icon: 'work' },
  ]}
/>
```
