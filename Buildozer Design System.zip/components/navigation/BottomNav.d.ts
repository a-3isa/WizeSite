import React from 'react';

export interface BottomNavItem {
  value: string;
  label: string;
  /** Material Symbols icon name. */
  icon: string;
}

export interface BottomNavProps {
  items: BottomNavItem[];
  /** Active item value. */
  value: string;
  onChange?: (value: string) => void;
  style?: React.CSSProperties;
}

/**
 * Buildozer bottom navigation bar (orange pill indicator on the active item).
 */
export function BottomNav(props: BottomNavProps): JSX.Element;
