import React from 'react';

export interface ResourceCardProps {
  /** Material Symbols icon name. */
  icon: string;
  label: string;
  /** Accent color (also drives the 10% tinted background). */
  color?: string;
  onClick?: () => void;
  style?: React.CSSProperties;
}

/**
 * Buildozer dashboard resource link (Workers / Contractors / Equipment / Transport).
 */
export function ResourceCard(props: ResourceCardProps): JSX.Element;
