import React from 'react';
import { Icon } from '../base/Icon.jsx';

/**
 * ResourceCard — the compact tinted link used in the dashboard "Resources"
 * grid (Workers / Contractors / Equipment / Transport). Color at 10% fill,
 * an icon in full color, and a bold label.
 */
export function ResourceCard({ icon, label, color = 'var(--color-orange)', onClick, style, ...rest }) {
  const [hover, setHover] = React.useState(false);
  return (
    <button
      type="button"
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        width: '100%',
        padding: '10px',
        border: 'none',
        borderRadius: 'var(--radius-lg)',
        background: `color-mix(in srgb, ${color} ${hover ? 16 : 10}%, transparent)`,
        cursor: 'pointer',
        transition: 'background .15s ease',
        textAlign: 'left',
        ...style,
      }}
      {...rest}
    >
      <Icon name={icon} size={18} color={color} />
      <span
        style={{
          fontFamily: 'var(--font-sans)',
          fontSize: 'var(--fs-label)',
          fontWeight: 'var(--fw-bold)',
          color: 'var(--color-text)',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          whiteSpace: 'nowrap',
        }}
      >
        {label}
      </span>
    </button>
  );
}
