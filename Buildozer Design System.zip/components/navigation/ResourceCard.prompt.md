**ResourceCard** — compact tinted link in the dashboard Resources grid. The accent color fills the background at 10%.

```jsx
<ResourceCard icon="engineering" label="Workers" color="var(--color-warning)" />
<ResourceCard icon="handyman" label="Contractors" color="var(--color-orange)" />
<ResourceCard icon="construction" label="Equipment" color="var(--color-success)" />
<ResourceCard icon="local_shipping" label="Transport" color="var(--color-danger)" />
```
