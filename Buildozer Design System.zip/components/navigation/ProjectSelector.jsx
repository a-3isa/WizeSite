import React from 'react';
import { Icon } from '../base/Icon.jsx';

/**
 * ProjectSelector — the prominent orange dashboard control that scopes data to
 * a project. Orange 10% tinted surface, a work icon, a small orange "PROJECT"
 * overline and the extrabold project name, with a dropdown caret.
 */
export function ProjectSelector({
  project = 'All Projects',
  overline = 'PROJECT',
  open = false,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return (
    <button
      type="button"
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        width: '100%',
        padding: '9px 12px',
        border: 'none',
        borderRadius: 'var(--radius-md)',
        background: hover ? 'var(--color-orange-12)' : 'var(--color-orange-10)',
        cursor: 'pointer',
        transition: 'background .15s ease',
        textAlign: 'left',
        ...style,
      }}
      {...rest}
    >
      <Icon name="work" size={18} color="var(--color-orange)" />
      <span style={{ flex: 1, minWidth: 0 }}>
        <span
          style={{
            display: 'block',
            fontFamily: 'var(--font-sans)',
            fontSize: 'var(--fs-overline)',
            fontWeight: 'var(--fw-bold)',
            letterSpacing: '0.04em',
            color: 'var(--color-orange)',
          }}
        >
          {overline}
        </span>
        <span
          style={{
            display: 'block',
            fontFamily: 'var(--font-sans)',
            fontSize: 'var(--fs-body-sm)',
            fontWeight: 'var(--fw-extrabold)',
            color: 'var(--color-text)',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
          }}
        >
          {project}
        </span>
      </span>
      <Icon
        name={open ? 'arrow_drop_up' : 'arrow_drop_down'}
        size={22}
        color="var(--color-orange)"
      />
    </button>
  );
}
