import React from 'react';

export interface ProjectSelectorProps {
  /** Selected project name, or "All Projects". */
  project?: string;
  /** Overline label. Default "PROJECT". */
  overline?: string;
  /** Whether the menu is open (flips the caret). */
  open?: boolean;
  onClick?: () => void;
  style?: React.CSSProperties;
}

/**
 * Buildozer dashboard project scope selector (prominent orange control).
 */
export function ProjectSelector(props: ProjectSelectorProps): JSX.Element;
