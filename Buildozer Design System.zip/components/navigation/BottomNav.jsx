import React from 'react';
import { Icon } from '../base/Icon.jsx';

/**
 * BottomNav — the app's bottom navigation bar. White surface with a top-cast
 * shadow; the active item shows an orange pill indicator behind the icon and
 * an orange bold label. Matches the Flutter NavigationBar theme.
 */
export function BottomNav({ items = [], value, onChange, style, ...rest }) {
  return (
    <nav
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-around',
        background: 'var(--color-surface)',
        borderTop: '1px solid var(--color-border)',
        boxShadow: 'var(--shadow-nav)',
        padding: '8px 4px',
        ...style,
      }}
      {...rest}
    >
      {items.map((item) => {
        const active = item.value === value;
        return (
          <button
            key={item.value}
            type="button"
            onClick={() => onChange && onChange(item.value)}
            style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: 4,
              border: 'none',
              background: 'transparent',
              cursor: 'pointer',
              padding: '2px 8px',
              flex: 1,
            }}
          >
            <span
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
                width: 56,
                height: 30,
                borderRadius: 'var(--radius-pill)',
                background: active ? 'var(--color-orange-light)' : 'transparent',
                transition: 'background .15s ease',
              }}
            >
              <Icon
                name={item.icon}
                size={22}
                fill={active}
                color={active ? 'var(--color-orange)' : 'var(--color-text-body)'}
              />
            </span>
            <span
              style={{
                fontFamily: 'var(--font-sans)',
                fontSize: 11,
                fontWeight: active ? 'var(--fw-bold)' : 'var(--fw-medium)',
                color: active ? 'var(--color-orange)' : 'var(--color-text-body)',
              }}
            >
              {item.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
}
