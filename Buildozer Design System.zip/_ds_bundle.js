/* @ds-bundle: {"format":3,"namespace":"BuildozerDesignSystem_b69712","components":[{"name":"Chip","sourcePath":"components/base/Chip.jsx"},{"name":"Icon","sourcePath":"components/base/Icon.jsx"},{"name":"Card","sourcePath":"components/data-display/Card.jsx"},{"name":"MetricCard","sourcePath":"components/data-display/MetricCard.jsx"},{"name":"ProgressBar","sourcePath":"components/data-display/ProgressBar.jsx"},{"name":"SectionHeader","sourcePath":"components/data-display/SectionHeader.jsx"},{"name":"StatusTag","sourcePath":"components/data-display/StatusTag.jsx"},{"name":"TransactionRow","sourcePath":"components/data-display/TransactionRow.jsx"},{"name":"Badge","sourcePath":"components/feedback/Badge.jsx"},{"name":"EmptyState","sourcePath":"components/feedback/EmptyState.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Button","sourcePath":"components/forms/Button.jsx"},{"name":"IconButton","sourcePath":"components/forms/IconButton.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"TextField","sourcePath":"components/forms/TextField.jsx"},{"name":"BottomNav","sourcePath":"components/navigation/BottomNav.jsx"},{"name":"ProjectSelector","sourcePath":"components/navigation/ProjectSelector.jsx"},{"name":"ResourceCard","sourcePath":"components/navigation/ResourceCard.jsx"}],"sourceHashes":{"components/base/Chip.jsx":"926d659d2f59","components/base/Icon.jsx":"9d5410ff6fe5","components/data-display/Card.jsx":"e6ec3a8426f1","components/data-display/MetricCard.jsx":"ecb8f550af90","components/data-display/ProgressBar.jsx":"2fb901f79096","components/data-display/SectionHeader.jsx":"2b9d7de8d575","components/data-display/StatusTag.jsx":"fda93c71bf2d","components/data-display/TransactionRow.jsx":"cc0757b17797","components/feedback/Badge.jsx":"a4433a9234a6","components/feedback/EmptyState.jsx":"873c031d0173","components/feedback/Toast.jsx":"a9a23ea74a5b","components/forms/Button.jsx":"ecbef06d1428","components/forms/IconButton.jsx":"5a85561fca5e","components/forms/Select.jsx":"0c747061d0f7","components/forms/TextField.jsx":"2a8d72936180","components/navigation/BottomNav.jsx":"c8b29f84cb79","components/navigation/ProjectSelector.jsx":"b64ae78b2aa5","components/navigation/ResourceCard.jsx":"8ec490e8d5bf","ui_kits/mobile-app/AddExpenseScreen.jsx":"a3af61c326aa","ui_kits/mobile-app/DashboardScreen.jsx":"ce46e63d454a","ui_kits/mobile-app/LoginScreen.jsx":"34c303db71c2","ui_kits/mobile-app/PhoneFrame.jsx":"7d47ee32f46c","ui_kits/redesign/primitives.jsx":"358a2b4a8d94","ui_kits/redesign/strings.jsx":"46b7c54244e2","ui_kits/redesign/tweaks-panel.jsx":"6591467622ed"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.BuildozerDesignSystem_b69712 = window.BuildozerDesignSystem_b69712 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/base/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Icon — renders a Material Symbols Outlined glyph, the icon set the Buildozer
 * Flutter app uses (Material outlined icons). Pass the Material Symbols name.
 */
function Icon({
  name,
  size = 20,
  color = 'currentColor',
  weight = 400,
  fill = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    className: "material-symbols-outlined",
    "aria-hidden": "true",
    style: {
      fontSize: size,
      width: size,
      height: size,
      color,
      lineHeight: 1,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontVariationSettings: `'FILL' ${fill ? 1 : 0}, 'wght' ${weight}, 'GRAD' 0, 'opsz' 24`,
      userSelect: 'none',
      flexShrink: 0,
      ...style
    }
  }, rest), name);
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/base/Icon.jsx", error: String((e && e.message) || e) }); }

// components/base/Chip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Chip — the small pill used in the dashboard "Quick access" strip and for
 * resource categories. A leading color dot (or icon) plus a bold label on a
 * white bordered surface.
 */
function Chip({
  label,
  dotColor,
  icon,
  iconColor,
  active = false,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const clickable = !!onClick;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    disabled: !clickable,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      flex: '0 0 auto',
      padding: '9px 12px',
      borderRadius: 'var(--radius-md)',
      border: `1px solid ${active ? 'var(--color-orange)' : 'var(--color-border)'}`,
      background: active ? 'var(--color-orange-light)' : 'var(--color-surface)',
      color: active ? 'var(--color-orange)' : 'var(--color-text)',
      font: 'inherit',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-label)',
      fontWeight: 'var(--fw-bold)',
      cursor: clickable ? 'pointer' : 'default',
      boxShadow: hover && clickable ? 'var(--shadow-card)' : 'none',
      transition: 'box-shadow .15s, border-color .15s',
      ...style
    }
  }, rest), dotColor && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 9,
      height: 9,
      borderRadius: 3,
      background: dotColor,
      flexShrink: 0
    }
  }), icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 16,
    color: iconColor || 'var(--color-orange)'
  }), label);
}
Object.assign(__ds_scope, { Chip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/base/Chip.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Card — the base white surface used across the app: rounded, hairline border,
 * soft shadow. Everything (metrics, lists, budget bars) sits on this.
 */
function Card({
  padding = 14,
  radius = 'var(--radius-lg)',
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: 'var(--color-surface)',
      border: '1px solid var(--color-border)',
      borderRadius: radius,
      boxShadow: 'var(--shadow-card)',
      padding,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Card.jsx", error: String((e && e.message) || e) }); }

// components/data-display/MetricCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * MetricCard — the dashboard KPI card. White surface with a 3px colored top
 * bar, a label + circular tinted icon badge, and a large extrabold value.
 * Faithful to lib/core/widgets/metric_card.dart.
 */
function MetricCard({
  label,
  value,
  color = 'var(--color-text)',
  icon = 'bar_chart',
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: 'var(--color-surface)',
      border: '1px solid var(--color-border)',
      borderRadius: 'var(--radius-lg)',
      boxShadow: 'var(--shadow-card)',
      overflow: 'hidden',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 3,
      background: color
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 14px 14px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-label)',
      fontWeight: 'var(--fw-medium)',
      color: 'var(--color-text-body)',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: 26,
      height: 26,
      borderRadius: '50%',
      background: `color-mix(in srgb, ${color} 12%, transparent)`,
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 14,
    color: color
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10,
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-value)',
      fontWeight: 'var(--fw-extrabold)',
      letterSpacing: 'var(--ls-value)',
      color: 'var(--color-text)'
    }
  }, value)));
}
Object.assign(__ds_scope, { MetricCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/MetricCard.jsx", error: String((e && e.message) || e) }); }

// components/data-display/ProgressBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * ProgressBar — the budget-used bar. Rounded track (orange 10% tint) with an
 * orange fill; turns red when over budget. Matches the project budget bar.
 */
function ProgressBar({
  value = 0,
  color = 'var(--color-orange)',
  height = 8,
  track = 'var(--color-orange-10)',
  style,
  ...rest
}) {
  const pct = Math.max(0, Math.min(1, value)) * 100;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      height,
      background: track,
      borderRadius: 'var(--radius-sm)',
      overflow: 'hidden',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      width: `${pct}%`,
      height: '100%',
      background: color,
      borderRadius: 'var(--radius-sm)',
      transition: 'width .3s ease'
    }
  }));
}
Object.assign(__ds_scope, { ProgressBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/ProgressBar.jsx", error: String((e && e.message) || e) }); }

// components/data-display/SectionHeader.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SectionHeader — the uppercase-ish bold section label used above dashboard
 * groups ("Overview", "Resources", "Recent"). Optional trailing action.
 */
function SectionHeader({
  title,
  action,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-title)',
      fontWeight: 'var(--fw-bold)',
      color: 'var(--color-text)'
    }
  }, title), action);
}
Object.assign(__ds_scope, { SectionHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/SectionHeader.jsx", error: String((e && e.message) || e) }); }

// components/data-display/StatusTag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  success: {
    bg: 'var(--color-success-light)',
    fg: 'var(--color-success)'
  },
  warning: {
    bg: 'var(--color-warning-light)',
    fg: 'var(--color-warning)'
  },
  danger: {
    bg: 'var(--color-danger-light)',
    fg: 'var(--color-danger)'
  },
  orange: {
    bg: 'var(--color-orange-light)',
    fg: 'var(--color-orange)'
  },
  neutral: {
    bg: 'var(--color-bg)',
    fg: 'var(--color-text-body)'
  }
};

/**
 * StatusTag — a small rounded pill for statuses (payment status, NEW/NOW tags).
 * Tinted background + matching text color.
 */
function StatusTag({
  label,
  tone = 'neutral',
  style,
  ...rest
}) {
  const t = TONES[tone] || TONES.neutral;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      padding: '3px 10px',
      borderRadius: 'var(--radius-pill)',
      background: t.bg,
      color: t.fg,
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-overline)',
      fontWeight: 'var(--fw-bold)',
      letterSpacing: '0.03em',
      textTransform: 'uppercase',
      ...style
    }
  }, rest), label);
}
Object.assign(__ds_scope, { StatusTag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/StatusTag.jsx", error: String((e && e.message) || e) }); }

// components/data-display/TransactionRow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * TransactionRow — a row in the dashboard "Recent" list. Payments (funds in)
 * show a green south-west arrow and a green +amount; expenses (funds out) a red
 * north-east arrow and a red -amount.
 */
function TransactionRow({
  title,
  amount,
  type = 'expense',
  isLast = false,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const isPayment = type === 'payment';
  const color = isPayment ? 'var(--color-success)' : 'var(--color-danger)';
  const sign = isPayment ? '+' : '-';
  return /*#__PURE__*/React.createElement("div", _extends({
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '11px 12px',
      borderBottom: isLast ? 'none' : '1px solid var(--color-bg)',
      background: hover && onClick ? 'var(--color-bg)' : 'transparent',
      cursor: onClick ? 'pointer' : 'default',
      transition: 'background .12s ease',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: isPayment ? 'south_west' : 'north_east',
    size: 18,
    color: color
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-body-sm)',
      color: 'var(--color-text)',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, title), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-body-sm)',
      fontWeight: 'var(--fw-bold)',
      color
    }
  }, sign, amount));
}
Object.assign(__ds_scope, { TransactionRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/TransactionRow.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Badge — a small count indicator (e.g. unread notifications) that overlays a
 * child, or renders standalone. Danger-red dot with white number, like the
 * notifications Badge in the app bar.
 */
function Badge({
  count,
  dot = false,
  max = 99,
  children,
  color = 'var(--color-danger)',
  style,
  ...rest
}) {
  const show = dot || typeof count === 'number' && count > 0;
  const text = count > max ? `${max}+` : `${count}`;
  const badge = show && /*#__PURE__*/React.createElement("span", {
    style: {
      position: children ? 'absolute' : 'static',
      top: children ? -4 : undefined,
      right: children ? -4 : undefined,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      minWidth: dot ? 10 : 18,
      height: dot ? 10 : 18,
      padding: dot ? 0 : '0 5px',
      borderRadius: 'var(--radius-pill)',
      background: color,
      color: '#fff',
      fontFamily: 'var(--font-sans)',
      fontSize: 11,
      fontWeight: 'var(--fw-bold)',
      lineHeight: 1,
      border: children ? '2px solid var(--color-surface)' : 'none',
      boxSizing: 'border-box'
    }
  }, !dot && text);
  if (!children) return badge || null;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      position: 'relative',
      display: 'inline-flex',
      ...style
    }
  }, rest), children, badge);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Badge.jsx", error: String((e && e.message) || e) }); }

// components/feedback/EmptyState.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * EmptyState — the centered placeholder shown when a list has no data (recent
 * transactions, restricted reports). A muted circular icon, a message, and an
 * optional action.
 */
function EmptyState({
  icon = 'inbox',
  message,
  action,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      textAlign: 'center',
      gap: 12,
      padding: '32px 24px',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: 56,
      height: 56,
      borderRadius: '50%',
      background: 'var(--color-bg)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 26,
    color: "var(--color-text-body)"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-body-sm)',
      color: 'var(--color-text-body)',
      maxWidth: 260
    }
  }, message), action);
}
Object.assign(__ds_scope, { EmptyState });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/EmptyState.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Toast — the snackbar / inline notice. A dark or tinted pill with an optional
 * leading icon and a trailing text action. Used for "Queued for sync", errors.
 */
function Toast({
  message,
  icon,
  tone = 'dark',
  actionLabel,
  onAction,
  style,
  ...rest
}) {
  const tones = {
    dark: {
      bg: 'var(--color-text)',
      fg: '#fff',
      accent: '#fff'
    },
    success: {
      bg: 'var(--color-success-light)',
      fg: 'var(--color-success)',
      accent: 'var(--color-success)'
    },
    warning: {
      bg: 'var(--color-warning-light)',
      fg: '#7A4A00',
      accent: 'var(--color-warning)'
    },
    danger: {
      bg: 'var(--color-danger-light)',
      fg: 'var(--color-danger)',
      accent: 'var(--color-danger)'
    }
  };
  const t = tones[tone] || tones.dark;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '12px 14px',
      borderRadius: 'var(--radius-md)',
      background: t.bg,
      color: t.fg,
      boxShadow: 'var(--shadow-soft)',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-body-sm)',
      ...style
    }
  }, rest), icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 20,
    color: t.accent
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, message), actionLabel && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onAction,
    style: {
      border: 'none',
      background: 'transparent',
      color: t.accent,
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-body-sm)',
      fontWeight: 'var(--fw-bold)',
      cursor: 'pointer',
      padding: 0
    }
  }, actionLabel));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/forms/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Button — Buildozer's primary action control. Mirrors the Flutter FilledButton
 * (orange fill, white text) and OutlinedButton (bordered) themes: 12px radius,
 * bold label, tall touch target.
 */
function Button({
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  disabled = false,
  icon,
  iconRight,
  children,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const heights = {
    sm: 44,
    md: 52,
    lg: 56
  };
  const variants = {
    primary: {
      background: 'var(--color-orange)',
      color: '#fff',
      border: '1px solid transparent',
      hoverBg: '#E85F00'
    },
    secondary: {
      background: 'var(--color-surface)',
      color: 'var(--color-text)',
      border: '1px solid var(--color-border)',
      hoverBg: '#F1F5F9'
    },
    tonal: {
      background: 'var(--color-orange-light)',
      color: 'var(--color-orange)',
      border: '1px solid transparent',
      hoverBg: '#FFE3CE'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--color-orange)',
      border: '1px solid transparent',
      hoverBg: 'var(--color-orange-light)'
    }
  };
  const v = variants[variant] || variants.primary;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    onClick: disabled ? undefined : onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    disabled: disabled,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      height: heights[size],
      padding: size === 'sm' ? '0 16px' : '0 24px',
      width: fullWidth ? '100%' : 'auto',
      borderRadius: 'var(--radius-md)',
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--fw-bold)',
      fontSize: size === 'sm' ? 14 : 16,
      letterSpacing: 0,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      transition: 'background .15s ease, box-shadow .15s ease',
      background: hover && !disabled ? v.hoverBg : v.background,
      color: v.color,
      border: v.border,
      ...style
    }
  }, rest), icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: size === 'sm' ? 18 : 20,
    color: "currentColor"
  }), children, iconRight && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconRight,
    size: size === 'sm' ? 18 : 20,
    color: "currentColor"
  }));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Button.jsx", error: String((e && e.message) || e) }); }

// components/forms/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconButton — square icon-only control used in app bars (notifications,
 * settings, voice mic). Subtle tinted hover, circular hit area.
 */
function IconButton({
  icon,
  size = 40,
  iconSize,
  color = 'var(--color-text-body)',
  variant = 'plain',
  disabled = false,
  onClick,
  title,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const filled = variant === 'filled';
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    title: title,
    "aria-label": title,
    onClick: disabled ? undefined : onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    disabled: disabled,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: size,
      height: size,
      borderRadius: 'var(--radius-pill)',
      border: 'none',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      background: filled ? 'var(--color-orange)' : hover ? 'var(--color-orange-10)' : 'transparent',
      transition: 'background .15s ease',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: iconSize || Math.round(size * 0.55),
    color: filled ? '#fff' : color
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Select — the "below dropdown" field pattern from the app: a bordered field
 * that opens an inline menu of options beneath it. White surface, 12px radius,
 * focus/open border turns orange. Selected option is orange-tinted.
 */
function Select({
  label,
  value,
  placeholder = 'Select…',
  options = [],
  disabled = false,
  onChange,
  style,
  ...rest
}) {
  const [open, setOpen] = React.useState(false);
  const selected = options.find(o => o.value === value);
  const borderColor = open ? 'var(--color-orange)' : 'var(--color-border)';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      ...style
    }
  }, rest), label && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      marginBottom: 6,
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-label)',
      fontWeight: 'var(--fw-semibold)',
      color: 'var(--color-text-body)'
    }
  }, label), /*#__PURE__*/React.createElement("button", {
    type: "button",
    disabled: disabled,
    onClick: () => setOpen(o => !o),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      width: '100%',
      background: 'var(--color-surface)',
      border: `${open ? 2 : 1}px solid ${borderColor}`,
      borderRadius: 'var(--radius-md)',
      padding: open ? '15px' : '16px',
      cursor: disabled ? 'not-allowed' : 'pointer',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-body-sm)',
      fontWeight: 'var(--fw-semibold)',
      color: selected ? 'var(--color-text)' : 'var(--color-text-body)',
      textAlign: 'left'
    }
  }, selected?.icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: selected.icon,
    size: 18,
    color: "var(--color-orange)"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, selected ? selected.label : placeholder), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: open ? 'arrow_drop_up' : 'arrow_drop_down',
    size: 22,
    color: "var(--color-text-body)"
  })), open && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 6,
      background: 'var(--color-surface)',
      border: '1px solid var(--color-border)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-soft)',
      overflow: 'hidden'
    }
  }, options.map((opt, i) => {
    const isActive = opt.value === value;
    return /*#__PURE__*/React.createElement("button", {
      key: opt.value,
      type: "button",
      onClick: () => {
        onChange && onChange(opt.value);
        setOpen(false);
      },
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 9,
        width: '100%',
        padding: '11px 12px',
        border: 'none',
        borderBottom: i < options.length - 1 ? '1px solid var(--color-bg)' : 'none',
        background: isActive ? 'var(--color-orange-light)' : 'transparent',
        color: isActive ? 'var(--color-orange)' : 'var(--color-text)',
        fontFamily: 'var(--font-sans)',
        fontSize: 'var(--fs-body-sm)',
        fontWeight: isActive ? 'var(--fw-bold)' : 'var(--fw-medium)',
        cursor: 'pointer',
        textAlign: 'left'
      }
    }, opt.icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: opt.icon,
      size: 18,
      color: isActive ? 'var(--color-orange)' : 'var(--color-text-body)'
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1
      }
    }, opt.label), opt.hint && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 'var(--fs-label)',
        color: 'var(--color-text-body)',
        fontWeight: 'var(--fw-medium)'
      }
    }, opt.hint));
  })));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/TextField.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * TextField — the app's outlined input. White fill, 12px radius, hairline
 * border that turns orange (2px) on focus, red on error. Supports a floating
 * label, hint, error text and optional suffix (e.g. currency "EGP").
 */
function TextField({
  label,
  value,
  placeholder,
  suffix,
  hint,
  error,
  multiline = false,
  rows = 3,
  disabled = false,
  onChange,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const borderColor = error ? 'var(--color-danger)' : focus ? 'var(--color-orange)' : 'var(--color-border)';
  const fieldStyle = {
    display: 'flex',
    alignItems: 'center',
    gap: 8,
    background: disabled ? 'var(--color-bg)' : 'var(--color-surface)',
    border: `${focus && !error ? 2 : 1}px solid ${borderColor}`,
    borderRadius: 'var(--radius-md)',
    padding: focus && !error ? '15px 15px' : '16px',
    transition: 'border-color .15s ease'
  };
  const inputBase = {
    flex: 1,
    border: 'none',
    outline: 'none',
    background: 'transparent',
    font: 'inherit',
    fontFamily: 'var(--font-sans)',
    fontSize: 'var(--fs-body-sm)',
    fontWeight: 'var(--fw-semibold)',
    color: 'var(--color-text)',
    resize: multiline ? 'vertical' : 'none',
    width: '100%'
  };
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'block',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      marginBottom: 6,
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-label)',
      fontWeight: 'var(--fw-semibold)',
      color: 'var(--color-text-body)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: fieldStyle
  }, multiline ? /*#__PURE__*/React.createElement("textarea", _extends({
    rows: rows,
    value: value,
    placeholder: placeholder,
    disabled: disabled,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: inputBase
  }, rest)) : /*#__PURE__*/React.createElement("input", _extends({
    value: value,
    placeholder: placeholder,
    disabled: disabled,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: inputBase
  }, rest)), suffix && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-label)',
      fontWeight: 'var(--fw-semibold)',
      color: 'var(--color-text-body)'
    }
  }, suffix)), (error || hint) && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      marginTop: 6,
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-label)',
      color: error ? 'var(--color-danger)' : 'var(--color-text-body)'
    }
  }, error || hint));
}
Object.assign(__ds_scope, { TextField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/TextField.jsx", error: String((e && e.message) || e) }); }

// components/navigation/BottomNav.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * BottomNav — the app's bottom navigation bar. White surface with a top-cast
 * shadow; the active item shows an orange pill indicator behind the icon and
 * an orange bold label. Matches the Flutter NavigationBar theme.
 */
function BottomNav({
  items = [],
  value,
  onChange,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("nav", _extends({
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-around',
      background: 'var(--color-surface)',
      borderTop: '1px solid var(--color-border)',
      boxShadow: 'var(--shadow-nav)',
      padding: '8px 4px',
      ...style
    }
  }, rest), items.map(item => {
    const active = item.value === value;
    return /*#__PURE__*/React.createElement("button", {
      key: item.value,
      type: "button",
      onClick: () => onChange && onChange(item.value),
      style: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 4,
        border: 'none',
        background: 'transparent',
        cursor: 'pointer',
        padding: '2px 8px',
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        width: 56,
        height: 30,
        borderRadius: 'var(--radius-pill)',
        background: active ? 'var(--color-orange-light)' : 'transparent',
        transition: 'background .15s ease'
      }
    }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: item.icon,
      size: 22,
      fill: active,
      color: active ? 'var(--color-orange)' : 'var(--color-text-body)'
    })), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 11,
        fontWeight: active ? 'var(--fw-bold)' : 'var(--fw-medium)',
        color: active ? 'var(--color-orange)' : 'var(--color-text-body)'
      }
    }, item.label));
  }));
}
Object.assign(__ds_scope, { BottomNav });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/BottomNav.jsx", error: String((e && e.message) || e) }); }

// components/navigation/ProjectSelector.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * ProjectSelector — the prominent orange dashboard control that scopes data to
 * a project. Orange 10% tinted surface, a work icon, a small orange "PROJECT"
 * overline and the extrabold project name, with a dropdown caret.
 */
function ProjectSelector({
  project = 'All Projects',
  overline = 'PROJECT',
  open = false,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      width: '100%',
      padding: '9px 12px',
      border: 'none',
      borderRadius: 'var(--radius-md)',
      background: hover ? 'var(--color-orange-12)' : 'var(--color-orange-10)',
      cursor: 'pointer',
      transition: 'background .15s ease',
      textAlign: 'left',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "work",
    size: 18,
    color: "var(--color-orange)"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-overline)',
      fontWeight: 'var(--fw-bold)',
      letterSpacing: '0.04em',
      color: 'var(--color-orange)'
    }
  }, overline), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-body-sm)',
      fontWeight: 'var(--fw-extrabold)',
      color: 'var(--color-text)',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, project)), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: open ? 'arrow_drop_up' : 'arrow_drop_down',
    size: 22,
    color: "var(--color-orange)"
  }));
}
Object.assign(__ds_scope, { ProjectSelector });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/ProjectSelector.jsx", error: String((e && e.message) || e) }); }

// components/navigation/ResourceCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * ResourceCard — the compact tinted link used in the dashboard "Resources"
 * grid (Workers / Contractors / Equipment / Transport). Color at 10% fill,
 * an icon in full color, and a bold label.
 */
function ResourceCard({
  icon,
  label,
  color = 'var(--color-orange)',
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      width: '100%',
      padding: '10px',
      border: 'none',
      borderRadius: 'var(--radius-lg)',
      background: `color-mix(in srgb, ${color} ${hover ? 16 : 10}%, transparent)`,
      cursor: 'pointer',
      transition: 'background .15s ease',
      textAlign: 'left',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 18,
    color: color
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-label)',
      fontWeight: 'var(--fw-bold)',
      color: 'var(--color-text)',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, label));
}
Object.assign(__ds_scope, { ResourceCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/ResourceCard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/mobile-app/AddExpenseScreen.jsx
try { (() => {
// AddExpenseScreen — Buildozer expense form. Project + category selects, amount
// with EGP suffix, payment method/status, notes, voice mic action, save.
function AddExpenseScreen({
  onBack,
  onSave
}) {
  const {
    IconButton,
    Select,
    TextField,
    Button,
    Icon
  } = window.BuildozerDesignSystem_b69712;
  const [project, setProject] = React.useState('villa');
  const [category, setCategory] = React.useState('materials');
  const [method, setMethod] = React.useState('cash');
  const [status, setStatus] = React.useState('unpaid');
  const [amount, setAmount] = React.useState('1,250,000');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      fontFamily: 'var(--font-sans)',
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '4px 8px 8px',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "arrow_back",
    title: "Back",
    onClick: onBack
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 22,
      fontWeight: 700,
      color: 'var(--color-text)'
    }
  }, "Add Expense")), /*#__PURE__*/React.createElement(IconButton, {
    icon: "mic",
    variant: "filled",
    size: 44,
    title: "Voice entry"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: '4px 16px 16px',
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Select, {
    label: "Project",
    value: project,
    onChange: setProject,
    options: [{
      value: 'villa',
      label: 'Villa Project',
      icon: 'work'
    }, {
      value: 'tower',
      label: 'Tower B Renovation',
      icon: 'work'
    }, {
      value: 'warehouse',
      label: 'Warehouse Fit-out',
      icon: 'work'
    }]
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Category",
    value: category,
    onChange: setCategory,
    options: [{
      value: 'worker',
      label: 'Worker',
      icon: 'engineering',
      hint: 'daily wage'
    }, {
      value: 'contractor',
      label: 'Contractor',
      icon: 'handyman'
    }, {
      value: 'materials',
      label: 'Materials',
      icon: 'category'
    }, {
      value: 'equipment',
      label: 'Equipment',
      icon: 'construction'
    }, {
      value: 'transport',
      label: 'Transport',
      icon: 'local_shipping'
    }, {
      value: 'other',
      label: 'Other',
      icon: 'more_horiz'
    }]
  }), /*#__PURE__*/React.createElement(TextField, {
    label: "Amount",
    value: amount,
    suffix: "EGP",
    onChange: e => setAmount(e.target.value)
  }), /*#__PURE__*/React.createElement(TextField, {
    label: "Supplier name",
    placeholder: "Optional",
    onChange: () => {}
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Select, {
    label: "Payment method",
    value: method,
    onChange: setMethod,
    options: [{
      value: 'cash',
      label: 'Cash'
    }, {
      value: 'bank',
      label: 'Bank'
    }, {
      value: 'check',
      label: 'Check'
    }]
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Payment status",
    value: status,
    onChange: setStatus,
    options: [{
      value: 'unpaid',
      label: 'Unpaid'
    }, {
      value: 'partial',
      label: 'Partial'
    }, {
      value: 'paid',
      label: 'Paid'
    }]
  })), /*#__PURE__*/React.createElement(TextField, {
    label: "Notes",
    multiline: true,
    rows: 2,
    placeholder: "Add a note\u2026",
    onChange: () => {}
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    icon: "check",
    fullWidth: true,
    size: "lg",
    onClick: onSave,
    style: {
      marginTop: 4
    }
  }, "Save Expense")));
}
Object.assign(window, {
  AddExpenseScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mobile-app/AddExpenseScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/mobile-app/DashboardScreen.jsx
try { (() => {
// DashboardScreen — Buildozer home. Workspace title + notifications/settings,
// project selector, financial metric grid, budget bar, recent list, resources.
function DashboardScreen({
  onAdd,
  onOpenProject
}) {
  const {
    IconButton,
    Badge,
    ProjectSelector,
    SectionHeader,
    MetricCard,
    Card,
    ProgressBar,
    TransactionRow,
    ResourceCard,
    Icon
  } = window.BuildozerDesignSystem_b69712;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      fontFamily: 'var(--font-sans)',
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '4px 12px 8px',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 4px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 4,
      fontSize: 22,
      fontWeight: 700,
      color: 'var(--color-text)'
    }
  }, "Cairo Co.", /*#__PURE__*/React.createElement(Icon, {
    name: "arrow_drop_down",
    size: 22,
    color: "var(--color-text)"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    count: 3
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "notifications",
    title: "Notifications"
  })), /*#__PURE__*/React.createElement(IconButton, {
    icon: "settings",
    title: "Settings"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement(ProjectSelector, {
    project: "Villa Project",
    onClick: onOpenProject
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: '4px 16px 16px'
    }
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    title: "Overview",
    style: {
      margin: '6px 0 12px'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(MetricCard, {
    label: "Active projects",
    value: "7",
    color: "var(--color-orange)",
    icon: "work"
  }), /*#__PURE__*/React.createElement(MetricCard, {
    label: "Total expenses",
    value: "195,500",
    color: "var(--color-danger)",
    icon: "trending_down"
  }), /*#__PURE__*/React.createElement(MetricCard, {
    label: "Total income",
    value: "320,000",
    color: "var(--color-success)",
    icon: "trending_up"
  }), /*#__PURE__*/React.createElement(MetricCard, {
    label: "Net profit",
    value: "124,500",
    color: "var(--color-success)",
    icon: "trending_up"
  })), /*#__PURE__*/React.createElement(Card, {
    padding: 14,
    style: {
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      fontSize: 13,
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700,
      color: 'var(--color-text)'
    }
  }, "Budget used"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--color-text-body)'
    }
  }, "135,500 / 180,000")), /*#__PURE__*/React.createElement(ProgressBar, {
    value: 0.75
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      fontWeight: 700,
      color: 'var(--color-orange)',
      marginTop: 6
    }
  }, "75%")), /*#__PURE__*/React.createElement(SectionHeader, {
    title: "Recent",
    style: {
      margin: '20px 0 12px'
    }
  }), /*#__PURE__*/React.createElement(Card, {
    padding: 0
  }, /*#__PURE__*/React.createElement(TransactionRow, {
    type: "payment",
    title: "Owner deposit",
    amount: "120,000"
  }), /*#__PURE__*/React.createElement(TransactionRow, {
    type: "expense",
    title: "El-Nasr Supplies",
    amount: "45,000"
  }), /*#__PURE__*/React.createElement(TransactionRow, {
    type: "expense",
    title: "Worker wages",
    amount: "18,300",
    isLast: true
  })), /*#__PURE__*/React.createElement(SectionHeader, {
    title: "Resources",
    style: {
      margin: '20px 0 12px'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(ResourceCard, {
    icon: "engineering",
    label: "Workers",
    color: "var(--color-warning)"
  }), /*#__PURE__*/React.createElement(ResourceCard, {
    icon: "handyman",
    label: "Contractors",
    color: "var(--color-orange)"
  }), /*#__PURE__*/React.createElement(ResourceCard, {
    icon: "construction",
    label: "Equipment",
    color: "var(--color-success)"
  }), /*#__PURE__*/React.createElement(ResourceCard, {
    icon: "local_shipping",
    label: "Transport",
    color: "var(--color-danger)"
  }))));
}
Object.assign(window, {
  DashboardScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mobile-app/DashboardScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/mobile-app/LoginScreen.jsx
try { (() => {
// LoginScreen — Buildozer sign-in. Logo, welcome headline, Google button.
function LoginScreen({
  onSignIn
}) {
  const {
    Button
  } = window.BuildozerDesignSystem_b69712;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'stretch',
      justifyContent: 'center',
      padding: '0 28px',
      textAlign: 'center',
      fontFamily: 'var(--font-sans)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo/app_icon.png",
    width: "72",
    height: "72",
    alt: "Buildozer",
    style: {
      borderRadius: 16,
      alignSelf: 'center',
      marginBottom: 24
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 32,
      fontWeight: 900,
      letterSpacing: '-1px',
      color: 'var(--color-text)'
    }
  }, "Welcome back"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 16,
      color: 'var(--color-text-body)',
      marginTop: 8,
      marginBottom: 44
    }
  }, "Sign in to continue"), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onSignIn,
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 10,
      height: 56,
      borderRadius: 'var(--radius-md)',
      cursor: 'pointer',
      background: 'var(--color-surface)',
      border: '1px solid var(--color-border)',
      fontFamily: 'var(--font-sans)',
      fontSize: 16,
      fontWeight: 700,
      color: 'var(--color-text)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo/google_g.png",
    width: "20",
    height: "20",
    alt: ""
  }), "Continue with Google"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--color-text-body)',
      marginTop: 20,
      lineHeight: 1.5
    }
  }, "Field-ready construction tracking.", /*#__PURE__*/React.createElement("br", null), "Log expenses by voice, on site."));
}
Object.assign(window, {
  LoginScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mobile-app/LoginScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/mobile-app/PhoneFrame.jsx
try { (() => {
// PhoneFrame — a lightweight device bezel for the Buildozer app screens.
function PhoneFrame({
  children,
  statusColor = 'var(--color-text)'
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: 340,
      background: 'var(--color-text)',
      borderRadius: 42,
      padding: 10,
      boxShadow: '0 24px 60px rgba(15,23,42,0.28)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      background: 'var(--color-bg)',
      borderRadius: 32,
      overflow: 'hidden',
      height: 720,
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '10px 22px 4px',
      fontSize: 12,
      fontWeight: 700,
      color: statusColor,
      fontFamily: 'var(--font-sans)',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("span", null, "9:41"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      gap: 5,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-outlined",
    style: {
      fontSize: 15
    }
  }, "signal_cellular_alt"), /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-outlined",
    style: {
      fontSize: 15
    }
  }, "wifi"), /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-outlined",
    style: {
      fontSize: 16
    }
  }, "battery_full"))), children));
}
Object.assign(window, {
  PhoneFrame
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mobile-app/PhoneFrame.jsx", error: String((e && e.message) || e) }); }

// ui_kits/redesign/primitives.jsx
try { (() => {
// Buildozer v2 — shared primitives for the redesign prototype.
// All theming via CSS vars (theme.css) so light/dark + tweaks flow through.
(function () {
  const e = React.createElement;

  // ---- Icon (Material Symbols Outlined) ----
  function I({
    n,
    s = 22,
    c = 'currentColor',
    fill = false,
    w = 400,
    style
  }) {
    return e('span', {
      className: 'material-symbols-outlined',
      style: {
        fontSize: s,
        width: s,
        height: s,
        color: c,
        lineHeight: 1,
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontVariationSettings: `'FILL' ${fill ? 1 : 0}, 'wght' ${w}, 'GRAD' 0, 'opsz' 24`,
        flexShrink: 0,
        userSelect: 'none',
        ...style
      }
    }, n);
  }

  // ---- Card ----
  function Card({
    children,
    pad,
    style,
    onClick,
    elevated = false
  }) {
    return e('div', {
      onClick,
      style: {
        background: 'var(--surface)',
        border: '1px solid var(--border)',
        borderRadius: 'var(--r-lg)',
        boxShadow: elevated ? 'var(--shadow-md)' : 'var(--shadow-sm)',
        padding: pad != null ? pad : 'var(--card-pad)',
        cursor: onClick ? 'pointer' : 'default',
        ...style
      }
    }, children);
  }

  // ---- Button ----
  function Btn({
    children,
    variant = 'primary',
    size = 'md',
    icon,
    iconRight,
    full,
    disabled,
    onClick,
    style
  }) {
    const [h, setH] = React.useState(false);
    const heights = {
      sm: 40,
      md: 50,
      lg: 56
    };
    const V = {
      primary: {
        bg: h ? 'var(--accent-press)' : 'var(--accent)',
        c: 'var(--on-accent)',
        bd: 'transparent'
      },
      soft: {
        bg: 'var(--accent-soft)',
        c: 'var(--accent)',
        bd: 'transparent'
      },
      outline: {
        bg: h ? 'var(--surface-2)' : 'var(--surface)',
        c: 'var(--text)',
        bd: 'var(--border-strong)'
      },
      ghost: {
        bg: h ? 'var(--surface-2)' : 'transparent',
        c: 'var(--text)',
        bd: 'transparent'
      },
      danger: {
        bg: h ? 'var(--expense)' : 'var(--expense-soft)',
        c: h ? '#fff' : 'var(--expense)',
        bd: 'transparent'
      }
    }[variant];
    return e('button', {
      onMouseEnter: () => setH(true),
      onMouseLeave: () => setH(false),
      onClick: disabled ? undefined : onClick,
      disabled,
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        height: heights[size],
        padding: size === 'sm' ? '0 14px' : '0 20px',
        width: full ? '100%' : 'auto',
        borderRadius: 'var(--r-md)',
        background: V.bg,
        color: V.c,
        border: `1.5px solid ${V.bd}`,
        fontFamily: 'var(--font)',
        fontWeight: 700,
        fontSize: size === 'sm' ? 14 : 15.5,
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.5 : 1,
        transition: 'background .15s, opacity .15s',
        whiteSpace: 'nowrap',
        ...style
      }
    }, icon && e(I, {
      n: icon,
      s: size === 'sm' ? 18 : 20,
      c: 'currentColor'
    }), children, iconRight && e(I, {
      n: iconRight,
      s: size === 'sm' ? 18 : 20,
      c: 'currentColor'
    }));
  }

  // ---- Icon button ----
  function IconBtn({
    n,
    s = 42,
    c = 'var(--text)',
    fill,
    onClick,
    badge,
    title,
    style
  }) {
    const [h, setH] = React.useState(false);
    return e('button', {
      title,
      'aria-label': title,
      onClick,
      onMouseEnter: () => setH(true),
      onMouseLeave: () => setH(false),
      style: {
        position: 'relative',
        width: s,
        height: s,
        borderRadius: 'var(--r-pill)',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        border: 'none',
        background: h ? 'var(--surface-2)' : 'transparent',
        cursor: 'pointer',
        transition: 'background .15s',
        ...style
      }
    }, e(I, {
      n,
      s: Math.round(s * 0.52),
      c,
      fill
    }), badge ? e('span', {
      style: {
        position: 'absolute',
        top: 6,
        right: 6,
        minWidth: 8,
        height: 8,
        borderRadius: 999,
        background: 'var(--expense)',
        border: '2px solid var(--surface)'
      }
    }) : null);
  }

  // ---- Segmented control ----
  function Segmented({
    options,
    value,
    onChange,
    style
  }) {
    return e('div', {
      style: {
        display: 'inline-flex',
        background: 'var(--surface-2)',
        borderRadius: 'var(--r-pill)',
        padding: 3,
        gap: 2,
        ...style
      }
    }, options.map(o => {
      const on = o.value === value;
      return e('button', {
        key: o.value,
        onClick: () => onChange(o.value),
        style: {
          border: 'none',
          cursor: 'pointer',
          borderRadius: 'var(--r-pill)',
          padding: '6px 14px',
          fontFamily: 'var(--font)',
          fontSize: 13,
          fontWeight: 700,
          background: on ? 'var(--surface)' : 'transparent',
          color: on ? 'var(--text)' : 'var(--text-muted)',
          boxShadow: on ? 'var(--shadow-sm)' : 'none',
          transition: 'all .15s'
        }
      }, o.label);
    }));
  }

  // ---- Chip ----
  function Chip({
    label,
    icon,
    dot,
    active,
    onClick,
    style
  }) {
    return e('button', {
      onClick,
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 7,
        flex: '0 0 auto',
        padding: '9px 13px',
        borderRadius: 'var(--r-pill)',
        border: `1.5px solid ${active ? 'var(--accent)' : 'var(--border)'}`,
        background: active ? 'var(--accent-soft)' : 'var(--surface)',
        color: active ? 'var(--accent)' : 'var(--text)',
        fontFamily: 'var(--font)',
        fontSize: 13,
        fontWeight: 600,
        cursor: 'pointer',
        transition: 'all .15s',
        ...style
      }
    }, dot && e('span', {
      style: {
        width: 8,
        height: 8,
        borderRadius: 999,
        background: dot
      }
    }), icon && e(I, {
      n: icon,
      s: 16,
      c: active ? 'var(--accent)' : 'var(--text-muted)'
    }), label);
  }

  // ---- Progress bar ----
  function Progress({
    value,
    color = 'var(--accent)',
    track = 'var(--surface-3)',
    h = 8,
    style
  }) {
    return e('div', {
      style: {
        height: h,
        background: track,
        borderRadius: 999,
        overflow: 'hidden',
        ...style
      }
    }, e('div', {
      style: {
        width: `${Math.max(0, Math.min(1, value)) * 100}%`,
        height: '100%',
        background: color,
        borderRadius: 999,
        transition: 'width .4s'
      }
    }));
  }

  // ---- Section title ----
  function Section({
    title,
    action,
    onAction,
    style
  }) {
    return e('div', {
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: 12,
        ...style
      }
    }, e('span', {
      style: {
        fontFamily: 'var(--font)',
        fontSize: 17,
        fontWeight: 750,
        color: 'var(--text)',
        letterSpacing: '-0.2px'
      }
    }, title), action && e('button', {
      onClick: onAction,
      style: {
        border: 'none',
        background: 'transparent',
        color: 'var(--accent)',
        fontFamily: 'var(--font)',
        fontSize: 13.5,
        fontWeight: 700,
        cursor: 'pointer',
        display: 'inline-flex',
        alignItems: 'center',
        gap: 2
      }
    }, action));
  }

  // ---- Avatar ----
  function Avatar({
    label,
    size = 40,
    color = 'var(--accent)',
    style
  }) {
    const initials = (label || '?').split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
    return e('div', {
      style: {
        width: size,
        height: size,
        borderRadius: 999,
        flexShrink: 0,
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'var(--accent-soft)',
        color,
        fontFamily: 'var(--font)',
        fontWeight: 800,
        fontSize: size * 0.4,
        ...style
      }
    }, initials);
  }

  // ---- Money row (transaction) ----
  function MoneyRow({
    title,
    sub,
    amount,
    kind = 'expense',
    icon,
    currency = 'EGP',
    onClick,
    last
  }) {
    const income = kind === 'income';
    const col = income ? 'var(--income)' : 'var(--expense)';
    const softCol = income ? 'var(--income-soft)' : 'var(--expense-soft)';
    return e('div', {
      onClick,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        padding: '12px 4px',
        borderBottom: last ? 'none' : '1px solid var(--border)',
        cursor: onClick ? 'pointer' : 'default'
      }
    }, e('div', {
      style: {
        width: 40,
        height: 40,
        borderRadius: 12,
        flexShrink: 0,
        background: softCol,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }
    }, e(I, {
      n: icon || (income ? 'south_west' : 'north_east'),
      s: 20,
      c: col
    })), e('div', {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, e('div', {
      style: {
        fontFamily: 'var(--font)',
        fontSize: 14.5,
        fontWeight: 650,
        color: 'var(--text)',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap'
      }
    }, title), sub && e('div', {
      style: {
        fontFamily: 'var(--font)',
        fontSize: 12.5,
        color: 'var(--text-muted)',
        marginTop: 2
      }
    }, sub)), e('div', {
      style: {
        textAlign: 'end',
        flexShrink: 0
      }
    }, e('div', {
      style: {
        fontFamily: 'var(--font)',
        fontSize: 14.5,
        fontWeight: 750,
        color: col
      }
    }, `${income ? '+' : '−'}${amount}`), e('div', {
      style: {
        fontFamily: 'var(--font)',
        fontSize: 11,
        color: 'var(--text-faint)',
        marginTop: 1
      }
    }, currency)));
  }

  // ---- Form field (input) ----
  function Field({
    label,
    value,
    onChange,
    placeholder,
    suffix,
    type = 'text',
    style
  }) {
    const [f, setF] = React.useState(false);
    return e('label', {
      style: {
        display: 'block',
        ...style
      }
    }, label && e('span', {
      style: {
        display: 'block',
        marginBottom: 7,
        fontFamily: 'var(--font)',
        fontSize: 12.5,
        fontWeight: 650,
        color: 'var(--text-muted)'
      }
    }, label), e('div', {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        background: 'var(--surface)',
        border: `${f ? 2 : 1.5}px solid ${f ? 'var(--accent)' : 'var(--border-strong)'}`,
        borderRadius: 'var(--r-md)',
        padding: f ? '13px 15px' : '14px 16px',
        transition: 'border-color .15s'
      }
    }, e('input', {
      value,
      onChange,
      placeholder,
      type,
      onFocus: () => setF(true),
      onBlur: () => setF(false),
      style: {
        flex: 1,
        border: 'none',
        outline: 'none',
        background: 'transparent',
        fontFamily: 'var(--font)',
        fontSize: 16,
        fontWeight: 600,
        color: 'var(--text)',
        width: '100%'
      }
    }), suffix && e('span', {
      style: {
        fontFamily: 'var(--font)',
        fontSize: 13,
        fontWeight: 700,
        color: 'var(--text-muted)'
      }
    }, suffix)));
  }

  // ---- Select field (opens option list via onOpen) ----
  function SelectField({
    label,
    valueLabel,
    icon,
    placeholder,
    onClick,
    style
  }) {
    return e('div', {
      style
    }, label && e('span', {
      style: {
        display: 'block',
        marginBottom: 7,
        fontFamily: 'var(--font)',
        fontSize: 12.5,
        fontWeight: 650,
        color: 'var(--text-muted)'
      }
    }, label), e('button', {
      onClick,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        width: '100%',
        background: 'var(--surface)',
        border: '1.5px solid var(--border-strong)',
        borderRadius: 'var(--r-md)',
        padding: '14px 16px',
        cursor: 'pointer',
        textAlign: 'start'
      }
    }, icon && e(I, {
      n: icon,
      s: 20,
      c: 'var(--accent)'
    }), e('span', {
      style: {
        flex: 1,
        fontFamily: 'var(--font)',
        fontSize: 16,
        fontWeight: 650,
        color: valueLabel ? 'var(--text)' : 'var(--text-faint)'
      }
    }, valueLabel || placeholder), e(I, {
      n: 'expand_more',
      s: 22,
      c: 'var(--text-muted)'
    })));
  }
  window.BZ = {
    e,
    I,
    Card,
    Btn,
    IconBtn,
    Segmented,
    Chip,
    Progress,
    Section,
    Avatar,
    MoneyRow,
    Field,
    SelectField
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/redesign/primitives.jsx", error: String((e && e.message) || e) }); }

// ui_kits/redesign/strings.jsx
try { (() => {
// Buildozer v2 — strings (EN/AR) + demo data.
(function () {
  const STR = {
    en: {
      dir: 'ltr',
      font: "'Inter', system-ui, sans-serif",
      greeting: 'Good morning',
      workspace: 'Cairo Co.',
      allProjects: 'All projects',
      project: 'Project',
      netThisMonth: 'Net this month',
      income: 'Income',
      expenses: 'Expenses',
      week: 'Week',
      month: 'Month',
      budgetHealth: 'Budget health',
      activeProjects: 'Active projects',
      recent: 'Recent activity',
      seeAll: 'See all',
      quickAdd: 'Quick add',
      addExpense: 'Add expense',
      addPayment: 'Add payment',
      voice: 'Voice entry',
      workers: 'Workers',
      resources: 'Resources',
      home: 'Home',
      projects: 'Projects',
      activity: 'Activity',
      more: 'More',
      add: 'Add',
      contractors: 'Contractors',
      equipment: 'Equipment',
      transport: 'Transport',
      materials: 'Materials',
      budgetUsed: 'Budget used',
      ofContract: 'of contract value',
      onSite: 'on site',
      save: 'Save',
      cancel: 'Cancel',
      amount: 'Amount',
      category: 'Category',
      supplier: 'Supplier',
      method: 'Method',
      status: 'Status',
      notes: 'Notes',
      paid: 'Paid',
      partial: 'Partial',
      unpaid: 'Unpaid',
      cash: 'Cash',
      bank: 'Bank',
      check: 'Cheque',
      recordExpense: 'Record an expense',
      tapToSpeak: 'Tap to speak',
      listening: 'Listening…',
      review: 'Review',
      confirm: 'Confirm & save',
      transcript: 'Transcript',
      detected: 'We detected',
      settings: 'Settings',
      searchActivity: 'Search activity',
      filters: 'Filters',
      all: 'All',
      thisProject: 'This project',
      fundsIn: 'Funds in',
      spent: 'Spent',
      upgradePro: 'Upgrade to Pro',
      proSub: 'Unlimited projects & reports',
      welcome: 'Build with clarity',
      welcomeSub: 'Track every pound on every site — by voice, in seconds.',
      continueGoogle: 'Continue with Google',
      darkMode: 'Dark mode',
      language: 'Language',
      account: 'Account',
      preferences: 'Preferences',
      plan: 'Plan',
      appearance: 'Appearance',
      addNew: 'Add new',
      whatToAdd: 'What do you want to add?',
      expenseDesc: 'Money out — materials, wages, rent',
      paymentDesc: 'Money in — owner deposit, funds',
      startVoice: 'Or record it by voice',
      good: 'Looking good',
      team: 'Team',
      notifications: 'Notifications',
      markRead: 'Mark all read',
      profile: 'Profile',
      siteEngineer: 'Site Engineer',
      switchWorkspace: 'Switch workspace',
      editProfile: 'Edit profile',
      logout: 'Log out',
      thisWeek: 'This week',
      earlier: 'Earlier',
      email: 'Email',
      role: 'Role',
      memberSince: 'Member since',
      noNotifs: 'You are all caught up'
    },
    ar: {
      dir: 'rtl',
      font: "'Cairo', system-ui, sans-serif",
      greeting: 'صباح الخير',
      workspace: 'شركة القاهرة',
      allProjects: 'كل المشاريع',
      project: 'المشروع',
      netThisMonth: 'صافي هذا الشهر',
      income: 'الدخل',
      expenses: 'المصروفات',
      week: 'أسبوع',
      month: 'شهر',
      budgetHealth: 'حالة الميزانية',
      activeProjects: 'مشاريع نشطة',
      recent: 'النشاط الأخير',
      seeAll: 'عرض الكل',
      quickAdd: 'إضافة سريعة',
      addExpense: 'إضافة مصروف',
      addPayment: 'إضافة دفعة',
      voice: 'إدخال صوتي',
      workers: 'العمال',
      resources: 'الموارد',
      home: 'الرئيسية',
      projects: 'المشاريع',
      activity: 'النشاط',
      more: 'المزيد',
      add: 'إضافة',
      contractors: 'المقاولون',
      equipment: 'المعدات',
      transport: 'النقل',
      materials: 'المواد',
      budgetUsed: 'المستخدم من الميزانية',
      ofContract: 'من قيمة العقد',
      onSite: 'في الموقع',
      save: 'حفظ',
      cancel: 'إلغاء',
      amount: 'المبلغ',
      category: 'الفئة',
      supplier: 'المورّد',
      method: 'طريقة الدفع',
      status: 'الحالة',
      notes: 'ملاحظات',
      paid: 'مدفوع',
      partial: 'جزئي',
      unpaid: 'غير مدفوع',
      cash: 'نقدًا',
      bank: 'تحويل',
      check: 'شيك',
      recordExpense: 'سجّل مصروفًا',
      tapToSpeak: 'اضغط للتحدث',
      listening: 'جارٍ الاستماع…',
      review: 'مراجعة',
      confirm: 'تأكيد وحفظ',
      transcript: 'النص',
      detected: 'اكتشفنا',
      settings: 'الإعدادات',
      searchActivity: 'ابحث في النشاط',
      filters: 'تصفية',
      all: 'الكل',
      thisProject: 'هذا المشروع',
      fundsIn: 'وارد',
      spent: 'المصروف',
      upgradePro: 'الترقية إلى برو',
      proSub: 'مشاريع وتقارير غير محدودة',
      welcome: 'ابنِ بوضوح',
      welcomeSub: 'تابع كل جنيه في كل موقع — بالصوت، في ثوانٍ.',
      continueGoogle: 'المتابعة عبر جوجل',
      darkMode: 'الوضع الداكن',
      language: 'اللغة',
      account: 'الحساب',
      preferences: 'التفضيلات',
      plan: 'الباقة',
      appearance: 'المظهر',
      addNew: 'إضافة جديدة',
      whatToAdd: 'ماذا تريد أن تضيف؟',
      expenseDesc: 'صرف — مواد، أجور، إيجار',
      paymentDesc: 'وارد — دفعة المالك، تمويل',
      startVoice: 'أو سجّلها بالصوت',
      good: 'كل شيء جيد',
      team: 'الفريق',
      notifications: 'الإشعارات',
      markRead: 'تحديد الكل كمقروء',
      profile: 'الملف الشخصي',
      siteEngineer: 'مهندس موقع',
      switchWorkspace: 'تبديل مساحة العمل',
      editProfile: 'تعديل الملف',
      logout: 'تسجيل الخروج',
      thisWeek: 'هذا الأسبوع',
      earlier: 'سابقًا',
      email: 'البريد',
      role: 'الدور',
      memberSince: 'عضو منذ',
      noNotifs: 'لا إشعارات جديدة'
    }
  };
  const DATA = {
    projects: [{
      id: 'villa',
      name: {
        en: 'Villa October',
        ar: 'فيلا أكتوبر'
      },
      net: 84500,
      in: 220000,
      spent: 135500,
      budget: 180000,
      workers: 12,
      color: '#FF6D00'
    }, {
      id: 'tower',
      name: {
        en: 'Tower B Renovation',
        ar: 'تجديد برج ب'
      },
      net: -12000,
      in: 90000,
      spent: 102000,
      budget: 95000,
      workers: 8,
      color: '#2A6FDB'
    }, {
      id: 'warehouse',
      name: {
        en: 'Warehouse Fit-out',
        ar: 'تجهيز المستودع'
      },
      net: 46000,
      in: 160000,
      spent: 114000,
      budget: 200000,
      workers: 5,
      color: '#12A150'
    }, {
      id: 'road',
      name: {
        en: 'Road Works — Ph.2',
        ar: 'أعمال الطريق — م.٢'
      },
      net: 6200,
      in: 60000,
      spent: 53800,
      budget: 70000,
      workers: 20,
      color: '#7A5AE0'
    }],
    recent: [{
      id: 1,
      title: {
        en: 'Owner deposit',
        ar: 'دفعة المالك'
      },
      sub: {
        en: 'Villa October · Cash',
        ar: 'فيلا أكتوبر · نقدًا'
      },
      amount: '120,000',
      kind: 'income',
      icon: 'account_balance_wallet'
    }, {
      id: 2,
      title: {
        en: 'El-Nasr Supplies',
        ar: 'موردو النصر'
      },
      sub: {
        en: 'Materials · Unpaid',
        ar: 'مواد · غير مدفوع'
      },
      amount: '45,000',
      kind: 'expense',
      icon: 'category'
    }, {
      id: 3,
      title: {
        en: 'Worker wages',
        ar: 'أجور العمال'
      },
      sub: {
        en: '12 workers · 3 days',
        ar: '١٢ عامل · ٣ أيام'
      },
      amount: '18,300',
      kind: 'expense',
      icon: 'engineering'
    }, {
      id: 4,
      title: {
        en: 'Crane rental',
        ar: 'إيجار رافعة'
      },
      sub: {
        en: 'Equipment · Paid',
        ar: 'معدات · مدفوع'
      },
      amount: '9,500',
      kind: 'expense',
      icon: 'construction'
    }, {
      id: 5,
      title: {
        en: 'Progress payment',
        ar: 'دفعة مرحلية'
      },
      sub: {
        en: 'Tower B · Bank',
        ar: 'برج ب · تحويل'
      },
      amount: '75,000',
      kind: 'income',
      icon: 'account_balance'
    }],
    categories: [{
      id: 'materials',
      icon: 'category',
      label: {
        en: 'Materials',
        ar: 'المواد'
      },
      color: '#FF6D00'
    }, {
      id: 'worker',
      icon: 'engineering',
      label: {
        en: 'Worker',
        ar: 'عامل'
      },
      color: '#F59E0B'
    }, {
      id: 'contractor',
      icon: 'handyman',
      label: {
        en: 'Contractor',
        ar: 'مقاول'
      },
      color: '#2A6FDB'
    }, {
      id: 'equipment',
      icon: 'construction',
      label: {
        en: 'Equipment',
        ar: 'معدات'
      },
      color: '#12A150'
    }, {
      id: 'transport',
      icon: 'local_shipping',
      label: {
        en: 'Transport',
        ar: 'نقل'
      },
      color: '#E5484D'
    }, {
      id: 'other',
      icon: 'more_horiz',
      label: {
        en: 'Other',
        ar: 'أخرى'
      },
      color: '#7A5AE0'
    }],
    resources: [{
      id: 'workers',
      icon: 'engineering',
      label: {
        en: 'Workers',
        ar: 'العمال'
      },
      count: 45,
      color: '#F59E0B'
    }, {
      id: 'contractors',
      icon: 'handyman',
      label: {
        en: 'Contractors',
        ar: 'المقاولون'
      },
      count: 12,
      color: '#FF6D00'
    }, {
      id: 'equipment',
      icon: 'construction',
      label: {
        en: 'Equipment',
        ar: 'المعدات'
      },
      count: 18,
      color: '#12A150'
    }, {
      id: 'transport',
      icon: 'local_shipping',
      label: {
        en: 'Transport',
        ar: 'النقل'
      },
      count: 7,
      color: '#E5484D'
    }],
    notif: [{
      id: 1,
      icon: 'account_balance_wallet',
      color: '#12A150',
      title: {
        en: 'Owner deposit received',
        ar: 'تم استلام دفعة المالك'
      },
      sub: {
        en: '+120,000 EGP · Villa October',
        ar: '+١٢٠٬٠٠٠ ج.م · فيلا أكتوبر'
      },
      time: {
        en: '2h ago',
        ar: 'قبل ساعتين'
      },
      unread: true,
      group: 'week'
    }, {
      id: 2,
      icon: 'warning',
      color: '#E5484D',
      title: {
        en: 'Tower B is over budget',
        ar: 'برج ب تجاوز الميزانية'
      },
      sub: {
        en: '102,000 / 95,000 EGP',
        ar: '١٠٢٬٠٠٠ / ٩٥٬٠٠٠ ج.م'
      },
      time: {
        en: '5h ago',
        ar: 'قبل ٥ ساعات'
      },
      unread: true,
      group: 'week'
    }, {
      id: 3,
      icon: 'engineering',
      color: '#F59E0B',
      title: {
        en: 'Wages logged by voice',
        ar: 'تم تسجيل الأجور صوتيًا'
      },
      sub: {
        en: '12 workers · 3 days',
        ar: '١٢ عامل · ٣ أيام'
      },
      time: {
        en: 'Yesterday',
        ar: 'أمس'
      },
      unread: false,
      group: 'week'
    }, {
      id: 4,
      icon: 'cloud_done',
      color: '#2A6FDB',
      title: {
        en: 'Offline changes synced',
        ar: 'تمت مزامنة التغييرات'
      },
      sub: {
        en: '3 expenses uploaded',
        ar: 'تم رفع ٣ مصروفات'
      },
      time: {
        en: 'Mon',
        ar: 'الإثنين'
      },
      unread: false,
      group: 'earlier'
    }]
  };
  window.BZ_STR = STR;
  window.BZ_DATA = DATA;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/redesign/strings.jsx", error: String((e && e.message) || e) }); }

// ui_kits/redesign/tweaks-panel.jsx
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)

/* BEGIN USAGE */
// tweaks-panel.jsx
// Reusable Tweaks shell + form-control helpers.
// Exports (to window): useTweaks, TweaksPanel, TweakSection, TweakRow, TweakSlider,
//   TweakToggle, TweakRadio, TweakSelect, TweakText, TweakNumber, TweakColor, TweakButton.
//
// Owns the host protocol (listens for __activate_edit_mode / __deactivate_edit_mode,
// posts __edit_mode_available / __edit_mode_set_keys / __edit_mode_dismissed) so
// individual prototypes don't re-roll it. Ships a consistent set of controls so you
// don't hand-draw <input type="range">, segmented radios, steppers, etc.
//
// Usage (in an HTML file that loads React + Babel):
//
//   const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
//     "primaryColor": "#D97757",
//     "palette": ["#D97757", "#29261b", "#f6f4ef"],
//     "fontSize": 16,
//     "density": "regular",
//     "dark": false
//   }/*EDITMODE-END*/;
//
//   function App() {
//     const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
//     return (
//       <div style={{ fontSize: t.fontSize, color: t.primaryColor }}>
//         Hello
//         <TweaksPanel>
//           <TweakSection label="Typography" />
//           <TweakSlider label="Font size" value={t.fontSize} min={10} max={32} unit="px"
//                        onChange={(v) => setTweak('fontSize', v)} />
//           <TweakRadio  label="Density" value={t.density}
//                        options={['compact', 'regular', 'comfy']}
//                        onChange={(v) => setTweak('density', v)} />
//           <TweakSection label="Theme" />
//           <TweakColor  label="Primary" value={t.primaryColor}
//                        options={['#D97757', '#2A6FDB', '#1F8A5B', '#7A5AE0']}
//                        onChange={(v) => setTweak('primaryColor', v)} />
//           <TweakColor  label="Palette" value={t.palette}
//                        options={[['#D97757', '#29261b', '#f6f4ef'],
//                                  ['#475569', '#0f172a', '#f1f5f9']]}
//                        onChange={(v) => setTweak('palette', v)} />
//           <TweakToggle label="Dark mode" value={t.dark}
//                        onChange={(v) => setTweak('dark', v)} />
//         </TweaksPanel>
//       </div>
//     );
//   }
//
// TweakRadio is the segmented control for 2–3 short options (auto-falls-back to
// TweakSelect past ~16/~10 chars per label); reach for TweakSelect directly when
// options are many or long. For color tweaks always curate 3-4 options rather than
// a free picker; an option can also be a whole 2–5 color palette (the stored value
// is the array). The Tweak* controls are a floor, not a ceiling — build custom
// controls inside the panel if a tweak calls for UI they don't cover.
/* END USAGE */
// ─────────────────────────────────────────────────────────────────────────────

const __TWEAKS_STYLE = `
  .twk-panel{position:fixed;right:16px;bottom:16px;z-index:2147483646;width:280px;
    max-height:calc(100vh - 32px);display:flex;flex-direction:column;
    transform:scale(var(--dc-inv-zoom,1));transform-origin:bottom right;
    background:rgba(250,249,247,.78);color:#29261b;
    -webkit-backdrop-filter:blur(24px) saturate(160%);backdrop-filter:blur(24px) saturate(160%);
    border:.5px solid rgba(255,255,255,.6);border-radius:14px;
    box-shadow:0 1px 0 rgba(255,255,255,.5) inset,0 12px 40px rgba(0,0,0,.18);
    font:11.5px/1.4 ui-sans-serif,system-ui,-apple-system,sans-serif;overflow:hidden}
  .twk-hd{display:flex;align-items:center;justify-content:space-between;
    padding:10px 8px 10px 14px;cursor:move;user-select:none}
  .twk-hd b{font-size:12px;font-weight:600;letter-spacing:.01em}
  .twk-x{appearance:none;border:0;background:transparent;color:rgba(41,38,27,.55);
    width:22px;height:22px;border-radius:6px;cursor:default;font-size:13px;line-height:1}
  .twk-x:hover{background:rgba(0,0,0,.06);color:#29261b}
  .twk-body{padding:2px 14px 14px;display:flex;flex-direction:column;gap:10px;
    overflow-y:auto;overflow-x:hidden;min-height:0;
    scrollbar-width:thin;scrollbar-color:rgba(0,0,0,.15) transparent}
  .twk-body::-webkit-scrollbar{width:8px}
  .twk-body::-webkit-scrollbar-track{background:transparent;margin:2px}
  .twk-body::-webkit-scrollbar-thumb{background:rgba(0,0,0,.15);border-radius:4px;
    border:2px solid transparent;background-clip:content-box}
  .twk-body::-webkit-scrollbar-thumb:hover{background:rgba(0,0,0,.25);
    border:2px solid transparent;background-clip:content-box}
  .twk-row{display:flex;flex-direction:column;gap:5px}
  .twk-row-h{flex-direction:row;align-items:center;justify-content:space-between;gap:10px}
  .twk-lbl{display:flex;justify-content:space-between;align-items:baseline;
    color:rgba(41,38,27,.72)}
  .twk-lbl>span:first-child{font-weight:500}
  .twk-val{color:rgba(41,38,27,.5);font-variant-numeric:tabular-nums}

  .twk-sect{font-size:10px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;
    color:rgba(41,38,27,.45);padding:10px 0 0}
  .twk-sect:first-child{padding-top:0}

  .twk-field{appearance:none;box-sizing:border-box;width:100%;min-width:0;height:26px;padding:0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;
    background:rgba(255,255,255,.6);color:inherit;font:inherit;outline:none}
  .twk-field:focus{border-color:rgba(0,0,0,.25);background:rgba(255,255,255,.85)}
  select.twk-field{padding-right:22px;
    background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'><path fill='rgba(0,0,0,.5)' d='M0 0h10L5 6z'/></svg>");
    background-repeat:no-repeat;background-position:right 8px center}

  .twk-slider{appearance:none;-webkit-appearance:none;width:100%;height:4px;margin:6px 0;
    border-radius:999px;background:rgba(0,0,0,.12);outline:none}
  .twk-slider::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;
    width:14px;height:14px;border-radius:50%;background:#fff;
    border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}
  .twk-slider::-moz-range-thumb{width:14px;height:14px;border-radius:50%;
    background:#fff;border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}

  .twk-seg{position:relative;display:flex;padding:2px;border-radius:8px;
    background:rgba(0,0,0,.06);user-select:none}
  .twk-seg-thumb{position:absolute;top:2px;bottom:2px;border-radius:6px;
    background:rgba(255,255,255,.9);box-shadow:0 1px 2px rgba(0,0,0,.12);
    transition:left .15s cubic-bezier(.3,.7,.4,1),width .15s}
  .twk-seg.dragging .twk-seg-thumb{transition:none}
  .twk-seg button{appearance:none;position:relative;z-index:1;flex:1;border:0;
    background:transparent;color:inherit;font:inherit;font-weight:500;min-height:22px;
    border-radius:6px;cursor:default;padding:4px 6px;line-height:1.2;
    overflow-wrap:anywhere}

  .twk-toggle{position:relative;width:32px;height:18px;border:0;border-radius:999px;
    background:rgba(0,0,0,.15);transition:background .15s;cursor:default;padding:0}
  .twk-toggle[data-on="1"]{background:#34c759}
  .twk-toggle i{position:absolute;top:2px;left:2px;width:14px;height:14px;border-radius:50%;
    background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.25);transition:transform .15s}
  .twk-toggle[data-on="1"] i{transform:translateX(14px)}

  .twk-num{display:flex;align-items:center;box-sizing:border-box;min-width:0;height:26px;padding:0 0 0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;background:rgba(255,255,255,.6)}
  .twk-num-lbl{font-weight:500;color:rgba(41,38,27,.6);cursor:ew-resize;
    user-select:none;padding-right:8px}
  .twk-num input{flex:1;min-width:0;height:100%;border:0;background:transparent;
    font:inherit;font-variant-numeric:tabular-nums;text-align:right;padding:0 8px 0 0;
    outline:none;color:inherit;-moz-appearance:textfield}
  .twk-num input::-webkit-inner-spin-button,.twk-num input::-webkit-outer-spin-button{
    -webkit-appearance:none;margin:0}
  .twk-num-unit{padding-right:8px;color:rgba(41,38,27,.45)}

  .twk-btn{appearance:none;height:26px;padding:0 12px;border:0;border-radius:7px;
    background:rgba(0,0,0,.78);color:#fff;font:inherit;font-weight:500;cursor:default}
  .twk-btn:hover{background:rgba(0,0,0,.88)}
  .twk-btn.secondary{background:rgba(0,0,0,.06);color:inherit}
  .twk-btn.secondary:hover{background:rgba(0,0,0,.1)}

  .twk-swatch{appearance:none;-webkit-appearance:none;width:56px;height:22px;
    border:.5px solid rgba(0,0,0,.1);border-radius:6px;padding:0;cursor:default;
    background:transparent;flex-shrink:0}
  .twk-swatch::-webkit-color-swatch-wrapper{padding:0}
  .twk-swatch::-webkit-color-swatch{border:0;border-radius:5.5px}
  .twk-swatch::-moz-color-swatch{border:0;border-radius:5.5px}

  .twk-chips{display:flex;gap:6px}
  .twk-chip{position:relative;appearance:none;flex:1;min-width:0;height:46px;
    padding:0;border:0;border-radius:6px;overflow:hidden;cursor:default;
    box-shadow:0 0 0 .5px rgba(0,0,0,.12),0 1px 2px rgba(0,0,0,.06);
    transition:transform .12s cubic-bezier(.3,.7,.4,1),box-shadow .12s}
  .twk-chip:hover{transform:translateY(-1px);
    box-shadow:0 0 0 .5px rgba(0,0,0,.18),0 4px 10px rgba(0,0,0,.12)}
  .twk-chip[data-on="1"]{box-shadow:0 0 0 1.5px rgba(0,0,0,.85),
    0 2px 6px rgba(0,0,0,.15)}
  .twk-chip>span{position:absolute;top:0;bottom:0;right:0;width:34%;
    display:flex;flex-direction:column;box-shadow:-1px 0 0 rgba(0,0,0,.1)}
  .twk-chip>span>i{flex:1;box-shadow:0 -1px 0 rgba(0,0,0,.1)}
  .twk-chip>span>i:first-child{box-shadow:none}
  .twk-chip svg{position:absolute;top:6px;left:6px;width:13px;height:13px;
    filter:drop-shadow(0 1px 1px rgba(0,0,0,.3))}
`;

// ── useTweaks ───────────────────────────────────────────────────────────────
// Single source of truth for tweak values. setTweak persists via the host
// (__edit_mode_set_keys → host rewrites the EDITMODE block on disk).
function useTweaks(defaults) {
  const [values, setValues] = React.useState(defaults);
  // Accepts either setTweak('key', value) or setTweak({ key: value, ... }) so a
  // useState-style call doesn't write a "[object Object]" key into the persisted
  // JSON block.
  const setTweak = React.useCallback((keyOrEdits, val) => {
    const edits = typeof keyOrEdits === 'object' && keyOrEdits !== null ? keyOrEdits : {
      [keyOrEdits]: val
    };
    setValues(prev => ({
      ...prev,
      ...edits
    }));
    window.parent.postMessage({
      type: '__edit_mode_set_keys',
      edits
    }, '*');
    // Same-window signal so in-page listeners (deck-stage rail thumbnails)
    // can react — the parent message only reaches the host, not peers.
    window.dispatchEvent(new CustomEvent('tweakchange', {
      detail: edits
    }));
  }, []);
  return [values, setTweak];
}

// ── TweaksPanel ─────────────────────────────────────────────────────────────
// Floating shell. Registers the protocol listener BEFORE announcing
// availability — if the announce ran first, the host's activate could land
// before our handler exists and the toolbar toggle would silently no-op.
// The close button posts __edit_mode_dismissed so the host's toolbar toggle
// flips off in lockstep; the host echoes __deactivate_edit_mode back which
// is what actually hides the panel.
function TweaksPanel({
  title = 'Tweaks',
  children
}) {
  const [open, setOpen] = React.useState(false);
  const dragRef = React.useRef(null);
  const offsetRef = React.useRef({
    x: 16,
    y: 16
  });
  const PAD = 16;
  const clampToViewport = React.useCallback(() => {
    const panel = dragRef.current;
    if (!panel) return;
    const w = panel.offsetWidth,
      h = panel.offsetHeight;
    const maxRight = Math.max(PAD, window.innerWidth - w - PAD);
    const maxBottom = Math.max(PAD, window.innerHeight - h - PAD);
    offsetRef.current = {
      x: Math.min(maxRight, Math.max(PAD, offsetRef.current.x)),
      y: Math.min(maxBottom, Math.max(PAD, offsetRef.current.y))
    };
    panel.style.right = offsetRef.current.x + 'px';
    panel.style.bottom = offsetRef.current.y + 'px';
  }, []);
  React.useEffect(() => {
    if (!open) return;
    clampToViewport();
    if (typeof ResizeObserver === 'undefined') {
      window.addEventListener('resize', clampToViewport);
      return () => window.removeEventListener('resize', clampToViewport);
    }
    const ro = new ResizeObserver(clampToViewport);
    ro.observe(document.documentElement);
    return () => ro.disconnect();
  }, [open, clampToViewport]);
  React.useEffect(() => {
    const onMsg = e => {
      const t = e?.data?.type;
      if (t === '__activate_edit_mode') setOpen(true);else if (t === '__deactivate_edit_mode') setOpen(false);
    };
    window.addEventListener('message', onMsg);
    window.parent.postMessage({
      type: '__edit_mode_available'
    }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);
  const dismiss = () => {
    setOpen(false);
    window.parent.postMessage({
      type: '__edit_mode_dismissed'
    }, '*');
  };
  const onDragStart = e => {
    const panel = dragRef.current;
    if (!panel) return;
    const r = panel.getBoundingClientRect();
    const sx = e.clientX,
      sy = e.clientY;
    const startRight = window.innerWidth - r.right;
    const startBottom = window.innerHeight - r.bottom;
    const move = ev => {
      offsetRef.current = {
        x: startRight - (ev.clientX - sx),
        y: startBottom - (ev.clientY - sy)
      };
      clampToViewport();
    };
    const up = () => {
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  };
  if (!open) return null;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("style", null, __TWEAKS_STYLE), /*#__PURE__*/React.createElement("div", {
    ref: dragRef,
    className: "twk-panel",
    "data-omelette-chrome": "",
    style: {
      right: offsetRef.current.x,
      bottom: offsetRef.current.y
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-hd",
    onMouseDown: onDragStart
  }, /*#__PURE__*/React.createElement("b", null, title), /*#__PURE__*/React.createElement("button", {
    className: "twk-x",
    "aria-label": "Close tweaks",
    onMouseDown: e => e.stopPropagation(),
    onClick: dismiss
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    className: "twk-body"
  }, children)));
}

// ── Layout helpers ──────────────────────────────────────────────────────────

function TweakSection({
  label,
  children
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "twk-sect"
  }, label), children);
}
function TweakRow({
  label,
  value,
  children,
  inline = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: inline ? 'twk-row twk-row-h' : 'twk-row'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label), value != null && /*#__PURE__*/React.createElement("span", {
    className: "twk-val"
  }, value)), children);
}

// ── Controls ────────────────────────────────────────────────────────────────

function TweakSlider({
  label,
  value,
  min = 0,
  max = 100,
  step = 1,
  unit = '',
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label,
    value: `${value}${unit}`
  }, /*#__PURE__*/React.createElement("input", {
    type: "range",
    className: "twk-slider",
    min: min,
    max: max,
    step: step,
    value: value,
    onChange: e => onChange(Number(e.target.value))
  }));
}
function TweakToggle({
  label,
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-row twk-row-h"
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "twk-toggle",
    "data-on": value ? '1' : '0',
    role: "switch",
    "aria-checked": !!value,
    onClick: () => onChange(!value)
  }, /*#__PURE__*/React.createElement("i", null)));
}
function TweakRadio({
  label,
  value,
  options,
  onChange
}) {
  const trackRef = React.useRef(null);
  const [dragging, setDragging] = React.useState(false);
  // The active value is read by pointer-move handlers attached for the lifetime
  // of a drag — ref it so a stale closure doesn't fire onChange for every move.
  const valueRef = React.useRef(value);
  valueRef.current = value;

  // Segments wrap mid-word once per-segment width runs out. The track is
  // ~248px (280 panel − 28 body pad − 4 seg pad), each button loses 12px
  // to its own padding, and 11.5px system-ui averages ~6.3px/char — so 2
  // options fit ~16 chars each, 3 fit ~10. Past that (or >3 options), fall
  // back to a dropdown rather than wrap.
  const labelLen = o => String(typeof o === 'object' ? o.label : o).length;
  const maxLen = options.reduce((m, o) => Math.max(m, labelLen(o)), 0);
  const fitsAsSegments = maxLen <= ({
    2: 16,
    3: 10
  }[options.length] ?? 0);
  if (!fitsAsSegments) {
    // <select> emits strings — map back to the original option value so the
    // fallback stays type-preserving (numbers, booleans) like the segment path.
    const resolve = s => {
      const m = options.find(o => String(typeof o === 'object' ? o.value : o) === s);
      return m === undefined ? s : typeof m === 'object' ? m.value : m;
    };
    return /*#__PURE__*/React.createElement(TweakSelect, {
      label: label,
      value: value,
      options: options,
      onChange: s => onChange(resolve(s))
    });
  }
  const opts = options.map(o => typeof o === 'object' ? o : {
    value: o,
    label: o
  });
  const idx = Math.max(0, opts.findIndex(o => o.value === value));
  const n = opts.length;
  const segAt = clientX => {
    const r = trackRef.current.getBoundingClientRect();
    const inner = r.width - 4;
    const i = Math.floor((clientX - r.left - 2) / inner * n);
    return opts[Math.max(0, Math.min(n - 1, i))].value;
  };
  const onPointerDown = e => {
    setDragging(true);
    const v0 = segAt(e.clientX);
    if (v0 !== valueRef.current) onChange(v0);
    const move = ev => {
      if (!trackRef.current) return;
      const v = segAt(ev.clientX);
      if (v !== valueRef.current) onChange(v);
    };
    const up = () => {
      setDragging(false);
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("div", {
    ref: trackRef,
    role: "radiogroup",
    onPointerDown: onPointerDown,
    className: dragging ? 'twk-seg dragging' : 'twk-seg'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-seg-thumb",
    style: {
      left: `calc(2px + ${idx} * (100% - 4px) / ${n})`,
      width: `calc((100% - 4px) / ${n})`
    }
  }), opts.map(o => /*#__PURE__*/React.createElement("button", {
    key: o.value,
    type: "button",
    role: "radio",
    "aria-checked": o.value === value
  }, o.label))));
}
function TweakSelect({
  label,
  value,
  options,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("select", {
    className: "twk-field",
    value: value,
    onChange: e => onChange(e.target.value)
  }, options.map(o => {
    const v = typeof o === 'object' ? o.value : o;
    const l = typeof o === 'object' ? o.label : o;
    return /*#__PURE__*/React.createElement("option", {
      key: v,
      value: v
    }, l);
  })));
}
function TweakText({
  label,
  value,
  placeholder,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("input", {
    className: "twk-field",
    type: "text",
    value: value,
    placeholder: placeholder,
    onChange: e => onChange(e.target.value)
  }));
}
function TweakNumber({
  label,
  value,
  min,
  max,
  step = 1,
  unit = '',
  onChange
}) {
  const clamp = n => {
    if (min != null && n < min) return min;
    if (max != null && n > max) return max;
    return n;
  };
  const startRef = React.useRef({
    x: 0,
    val: 0
  });
  const onScrubStart = e => {
    e.preventDefault();
    startRef.current = {
      x: e.clientX,
      val: value
    };
    const decimals = (String(step).split('.')[1] || '').length;
    const move = ev => {
      const dx = ev.clientX - startRef.current.x;
      const raw = startRef.current.val + dx * step;
      const snapped = Math.round(raw / step) * step;
      onChange(clamp(Number(snapped.toFixed(decimals))));
    };
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-num"
  }, /*#__PURE__*/React.createElement("span", {
    className: "twk-num-lbl",
    onPointerDown: onScrubStart
  }, label), /*#__PURE__*/React.createElement("input", {
    type: "number",
    value: value,
    min: min,
    max: max,
    step: step,
    onChange: e => onChange(clamp(Number(e.target.value)))
  }), unit && /*#__PURE__*/React.createElement("span", {
    className: "twk-num-unit"
  }, unit));
}

// Relative-luminance contrast pick — checkmarks drawn over a swatch need to
// read on both #111 and #fafafa without per-option configuration. Hex input
// only (#rgb / #rrggbb); named or rgb()/hsl() colors fall through to "light".
function __twkIsLight(hex) {
  const h = String(hex).replace('#', '');
  const x = h.length === 3 ? h.replace(/./g, c => c + c) : h.padEnd(6, '0');
  const n = parseInt(x.slice(0, 6), 16);
  if (Number.isNaN(n)) return true;
  const r = n >> 16 & 255,
    g = n >> 8 & 255,
    b = n & 255;
  return r * 299 + g * 587 + b * 114 > 148000;
}
const __TwkCheck = ({
  light
}) => /*#__PURE__*/React.createElement("svg", {
  viewBox: "0 0 14 14",
  "aria-hidden": "true"
}, /*#__PURE__*/React.createElement("path", {
  d: "M3 7.2 5.8 10 11 4.2",
  fill: "none",
  strokeWidth: "2.2",
  strokeLinecap: "round",
  strokeLinejoin: "round",
  stroke: light ? 'rgba(0,0,0,.78)' : '#fff'
}));

// TweakColor — curated color/palette picker. Each option is either a single
// hex string or an array of 1-5 hex strings; the card adapts — a lone color
// renders solid, a palette renders colors[0] as the hero (left ~2/3) with the
// rest stacked in a sharp column on the right. onChange emits the
// option in the shape it was passed (string stays string, array stays array).
// Without options it falls back to the native color input for back-compat.
function TweakColor({
  label,
  value,
  options,
  onChange
}) {
  if (!options || !options.length) {
    return /*#__PURE__*/React.createElement("div", {
      className: "twk-row twk-row-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "twk-lbl"
    }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("input", {
      type: "color",
      className: "twk-swatch",
      value: value,
      onChange: e => onChange(e.target.value)
    }));
  }
  // Native <input type=color> emits lowercase hex per the HTML spec, so
  // compare case-insensitively. String() guards JSON.stringify(undefined),
  // which returns the primitive undefined (no .toLowerCase).
  const key = o => String(JSON.stringify(o)).toLowerCase();
  const cur = key(value);
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-chips",
    role: "radiogroup"
  }, options.map((o, i) => {
    const colors = Array.isArray(o) ? o : [o];
    const [hero, ...rest] = colors;
    const sup = rest.slice(0, 4);
    const on = key(o) === cur;
    return /*#__PURE__*/React.createElement("button", {
      key: i,
      type: "button",
      className: "twk-chip",
      role: "radio",
      "aria-checked": on,
      "data-on": on ? '1' : '0',
      "aria-label": colors.join(', '),
      title: colors.join(' · '),
      style: {
        background: hero
      },
      onClick: () => onChange(o)
    }, sup.length > 0 && /*#__PURE__*/React.createElement("span", null, sup.map((c, j) => /*#__PURE__*/React.createElement("i", {
      key: j,
      style: {
        background: c
      }
    }))), on && /*#__PURE__*/React.createElement(__TwkCheck, {
      light: __twkIsLight(hero)
    }));
  })));
}
function TweakButton({
  label,
  onClick,
  secondary = false
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: secondary ? 'twk-btn secondary' : 'twk-btn',
    onClick: onClick
  }, label);
}
Object.assign(window, {
  useTweaks,
  TweaksPanel,
  TweakSection,
  TweakRow,
  TweakSlider,
  TweakToggle,
  TweakRadio,
  TweakSelect,
  TweakText,
  TweakNumber,
  TweakColor,
  TweakButton
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/redesign/tweaks-panel.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Chip = __ds_scope.Chip;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.MetricCard = __ds_scope.MetricCard;

__ds_ns.ProgressBar = __ds_scope.ProgressBar;

__ds_ns.SectionHeader = __ds_scope.SectionHeader;

__ds_ns.StatusTag = __ds_scope.StatusTag;

__ds_ns.TransactionRow = __ds_scope.TransactionRow;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.EmptyState = __ds_scope.EmptyState;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.TextField = __ds_scope.TextField;

__ds_ns.BottomNav = __ds_scope.BottomNav;

__ds_ns.ProjectSelector = __ds_scope.ProjectSelector;

__ds_ns.ResourceCard = __ds_scope.ResourceCard;

})();
